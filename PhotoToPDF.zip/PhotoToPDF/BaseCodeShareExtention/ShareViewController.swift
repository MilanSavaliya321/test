//
//  ShareViewController.swift
//  BaseCodeShareExtention
//
//  Created by AKASH BOGHANI on 18/03/24.
//

import UIKit
import Social

class ShareViewController: SLComposeServiceViewController {
    
    override func isContentValid() -> Bool {
        // Do validation of contentText and/or NSExtensionContext attachments here
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .clear
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        guard let extensionItem = extensionContext?.inputItems.first as? NSExtensionItem,
              let itemProvider = extensionItem.attachments?.first else {
            close()
            return
        }
        
        guard itemProvider.hasItemConformingToTypeIdentifier("public.url") else {
            close()
            return
        }
        
        let semaphore = DispatchSemaphore(value: 0)
        var fileURL: URL?
        
        itemProvider.loadItem(forTypeIdentifier: "public.url", options: nil) { item, error in
            defer {
                semaphore.signal()
            }
            
            guard let url = item as? URL else {
                self.close()
                return
            }
            
            fileURL = url
            self.openURL(url: NSURL(string:"openPdf://OpenVC?url=\(fileURL?.absoluteString ?? "")")!)
        }
    }
    
    func close() {
        self.extensionContext?.completeRequest(returningItems: [], completionHandler: nil)
    }
    
    override func didSelectPost() {
        // This is called after the user selects Post. Do the upload of contentText and/or NSExtensionContext attachments.
        
        
        // Inform the host that we're done, so it un-blocks its UI. Note: Alternatively you could call super's -didSelectPost, which will similarly complete the extension context.
        self.close()
    }
    
    override func configurationItems() -> [Any]! {
        // To add configuration options via table cells at the bottom of the sheet, return an array of SLComposeSheetConfigurationItem here.
        return []
    }
    
}

extension SLComposeServiceViewController {
    func openURL(url: NSURL) {
        do {
            let application = try self.sharedApplication()
            application.performSelector(inBackground: #selector(UIApplication.openURL(_:)), with: url)
        } catch {
            return
        }
    }
    
    func sharedApplication() throws -> UIApplication {
        var responder: UIResponder? = self
        while responder != nil {
            if let application = responder as? UIApplication {
                return application
            }
            
            responder = responder?.next
        }
        
        throw NSError(domain: "UIInputViewController+sharedApplication.swift", code: 1, userInfo: nil)
    }
}
