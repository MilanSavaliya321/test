//
//  SceneDelegate.swift
//  BaseCode
//
//  Created by  on 26/07/2023.
//

import SwiftDI
import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?
    var router: Router?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {

        guard let windowScene = (scene as? UIWindowScene) else {
            return
        }

        window = UIWindow(windowScene: windowScene)
        configureApp(route: .splash)
    }

    private func configureApp(route: Route) {
        let navigationController = UINavigationController()
        let router = AppRouter(
            navigationController: navigationController,
            route: route
        )
        self.router = router
        window?.rootViewController = navigationController
        window?.makeKeyAndVisible()

        Resolver.default.register(
            type: Router.self,
            factory: { router }
        )

        registerDependencies()
        
        router.start()
    }

    private func registerDependencies() {
        // TODO: Register dependencies such as repositories, managers etc
    }
    
    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        guard let url = URLContexts.first?.url else {
            return
        }
        
        let urlPath : String = url.absoluteString
        if urlPath.contains("OpenVC") {
            let component = url.query()?.split(separator: "=").last?.string ?? ""
            configureApp(route: .docxsToPdf(docxUrl: component))
        }
    }
}

