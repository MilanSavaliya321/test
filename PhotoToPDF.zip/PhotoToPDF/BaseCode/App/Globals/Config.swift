//
//  Config.swift
//  BaseCode
//
//  Created by  on 27/07/2023.
//

import Foundation

struct Config {

    static let inter = "Inter"
    static let poppins = "Poppins"
}
