//
//  HomeViewController.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 12/11/2023.
//

import MobileCoreServices
import Photos
import PhotosUI
import StoreKit
import UIKit
import VisionKit
import PDFKit

class HomeViewController: ViewController<HomeViewModel> {
    
    //MARK: - Outlets
    
    @IBOutlet var homeView: HomeView!
    var isMergeSelected = false
    var isCompressSelected = false
    var isDocFileSelected = false
    
    //MARK: - Lifecycle Methods

    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewModel.fetchAllPDFs()
        pdfTableViewSetup()
        homeView.searchTextField.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        homeView.isProButton.isHidden = StorageService.isSubscribed
        navigationController?.isNavigationBarHidden = true
        if StorageService.savedPDFs == 1 {
            SKStoreReviewController.requestReview()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        navigationController?.isNavigationBarHidden = false
    }
    
    override func setupBinding() {
        super.setupBinding()
        
        viewModel
            .$isFavoriteSelected
            .receive(on: DispatchQueue.main)
            .sink { [weak self] isFavorite in
                guard let self = self else { return }
                homeView.favoriteButton.setImage(
                    isFavorite ? Asset.favouriteSelected.image : Asset.favouriteUnSelected.image,
                    for: .normal
                )
            }
            .store(in: &bag)
        
        viewModel
            .$sharePDF
            .receive(on: DispatchQueue.main)
            .compactMap { $0 }
            .sink { [weak self] url in
                guard let self = self else { return }
                let activityViewController = UIActivityViewController(
                    activityItems: [url],
                    applicationActivities: nil
                )
                activityViewController.popoverPresentationController?.sourceView = view
                present(activityViewController, animated: true, completion: nil)
            }
            .store(in: &bag)
        
        viewModel
            .refreshPDfs = { [weak self] in
                guard let self = self else { return }
                homeView.pdfTableView.reloadData()
                homeView.noPDFsLabel.isHidden = !viewModel.pdfFiles.isEmpty
                homeView.selectButton.isHidden = viewModel.pdfFiles.isEmpty
            }
        
        viewModel
            .$deleteLockedFilePopup
            .compactMap { $0 }
            .sink { [weak self] indexPath in
                guard let self = self else { return }
                
                deleteFilesConfirmationDialog1(isProtectedFile: viewModel.isSelectedFileProtected){
                    self.viewModel.deleteFile(at: indexPath)
                    
                }
//                let alertController = UIAlertController(
//                    title: "This file is password protected.",
//                    message: "Do you still want to delete it?",
//                    preferredStyle: .alert
//                )
//                
//                let yesAction = UIAlertAction(title: "Yes", style: .destructive) { _ in
//                    self.viewModel.deleteFile(at: indexPath)
//                }
//                
//                let noAction = UIAlertAction(title: "No", style: .default) { _ in }
//                
//                alertController.addAction(yesAction)
//                alertController.addAction(noAction)
//                
//                present(alertController, animated: true, completion: nil)
            }
            .store(in: &bag)
    }
    
    //MARK: - Action Methods
    
    @IBAction
    func isProButtonTapped(_ sender: Any) {
        viewModel.handleIsProButtonTapped()
    }
    
    @IBAction
    func favouriteButtonTapped(_ sender: Any) {
        viewModel.handleFavoriteButtonTapped()
    }
    
    @IBAction
    func settingsButtonTapped(_ sender: Any) {
        viewModel.handleSettingsTapped()
    }
    
    @IBAction
    func searchTextChanged(_ textField: UITextField) {
        viewModel.searchedText = textField.text ?? .empty
    }
    
    @IBAction
    func filterButtonTapped(_ sender: Any) {
        viewModel.handleFilterTapped()
    }
    
    @IBAction
    func selectButtonTapped(_ sender: UIButton) {
        viewModel.isSelection = !viewModel.isSelection
        viewModel.selectedPdfs = []
        homeView.addView.isHidden = viewModel.isSelection
        homeView.selectOptionsView.isHidden = !viewModel.isSelection
        self.homeView.selectButton.setTitle(viewModel.isSelection ? "Cancel" : "Select", for: .normal)
        self.homeView.pdfTableView.reloadData()
    }
    
    
   
    
    @IBAction
    func optionButtonTapped(_ sender: UIButton) {
        if viewModel.checkIfAnySelectedPDFisLocked() && (sender.tag == 1 || sender.tag == 2) {
            let alertController = UIAlertController(
                title: "Error",
                message: "You have selected one or more locked files, Please unlock them first.",
                preferredStyle: .alert
            )
            let okAction = UIAlertAction(title: "Ok", style: .default) { _ in
                alertController.dismiss(animated: true)
            }
            alertController.addAction(okAction)
            self.present(alertController, animated: true, completion: nil)
            return
        }
        
        
        if viewModel.selectedPdfs.isEmpty {
            let alertController = UIAlertController(
                title: "Error",
                message: "Please select at least one file",
                preferredStyle: .alert
            )
            let okAction = UIAlertAction(title: "Ok", style: .default) { _ in
                alertController.dismiss(animated: true)
            }
            alertController.addAction(okAction)
            self.present(alertController, animated: true, completion: nil)
            return
        }
        
        let tag = sender.tag
        if tag == 0 { // For Share
            viewModel.handleShareTapped(completion: { urls in
                if self.viewModel.isSelection {
                    self.selectButtonTapped(UIButton())
                }
                let activityViewController = UIActivityViewController(
                    activityItems: urls,
                    applicationActivities: nil
                )
                activityViewController.popoverPresentationController?.sourceView = view
                self.present(activityViewController, animated: true, completion: nil)
            })
        } else if tag == 1 { // For Merge
            viewModel.handleMergeTapped()
            if viewModel.isSelection {
                selectButtonTapped(UIButton())
            }
        } else if tag == 2 { // For Compress
            viewModel.handleCompressTapped(onCompress: {
                self.confirmCompressOptionsMultiple(data: $0)
                if self.viewModel.isSelection {
                    self.selectButtonTapped(UIButton())
                }
            })
        } else if tag == 3 { // For Delete
            deleteFilesConfirmationDialog1(isProtectedFile:false){
                self.viewModel.deleteFiles {
                    if self.viewModel.isSelection {
                        self.selectButtonTapped(UIButton())
                    }
                }
            }
        }
    }
    
    func deleteFileConfirmationDialog(){
      let alertController = UIAlertController(
                title:"",
                message: "Are you sure you want to delete this file. This action cannot be undone.",
                preferredStyle: .alert
            )
            let okAction = UIAlertAction(title: "Delete", style: .default) { _ in
                alertController.dismiss(animated: true)
                self.viewModel.deleteFiles {
                    if self.viewModel.isSelection {
                        self.selectButtonTapped(UIButton())
                    }
                }
//                self.viewModel.handleDeleteTapped {
//                    if self.viewModel.isSelection {
//                        self.selectButtonTapped(UIButton())
//                    }
//                }
                
            }
            let cancel = UIAlertAction(title: "Cancel", style: .default) { _ in
                alertController.dismiss(animated: true)
            }
        alertController.addAction(cancel)
        alertController.addAction(okAction)
          
            self.present(alertController, animated: true, completion: nil)
            return
        
    }
    
    
    func deleteFilesConfirmationDialog1(isProtectedFile:Bool, onPostiveClick: @escaping () -> Void){
     
    
        var title = "Delete file"
        var message = "Are you sure you want to delete this file? This action cannot be undone."
      
        if(isProtectedFile){
            
            title = "This file is password protected.";
            message = "\(message)";
        }
        let alertController = UIAlertController(
                title:title,
                message: message,
                preferredStyle: .alert
            )
            let okAction = UIAlertAction(title: "Delete", style: .default) { _ in
                alertController.dismiss(animated: true)
                onPostiveClick();
            }
            let cancel = UIAlertAction(title: "Cancel", style: .default) { _ in
                alertController.dismiss(animated: true)
            }
        alertController.addAction(cancel)
        alertController.addAction(okAction)
          
            self.present(alertController, animated: true, completion: nil)
            return
        
    }
    
    @IBAction
    func addButtonTapped(_ sender: Any) {
        viewModel.pdfsToMergeOrCompress = []
        guard StorageService.isSubscribed || StorageService.savedPDFs < 3 else {
            viewModel.router.append(.upgradeToProVersion)
            return
        }
        viewModel.router.showSheet(.photosSelection(selectionClosure: { selectedOption in
            switch selectedOption {
            case .scan:
                let imageScanner = VNDocumentCameraViewController()
                imageScanner.delegate = self
                self.present(imageScanner, animated: true)
            case .icloud:
                let documentPicker = UIDocumentPickerViewController(documentTypes: [kUTTypeImage as String], in: .import)
                documentPicker.delegate = self
                documentPicker.allowsMultipleSelection = true
                self.present(documentPicker, animated: true, completion: nil)
            case .library:
                var configuration = PHPickerConfiguration()
                if StorageService.isSubscribed {
                    configuration.selectionLimit = .max
                } else {
                    configuration.selectionLimit = 5
                }
                configuration.filter = .images
                let picker = PHPickerViewController(configuration: configuration)
                picker.delegate = self
                self.present(picker, animated: true)
            case .compress, .merge:
                let documentPicker = UIDocumentPickerViewController(documentTypes: [kUTTypePDF as String], in: .import)
                documentPicker.delegate = self
                documentPicker.allowsMultipleSelection = true
                self.isMergeSelected = selectedOption == .merge
                self.isCompressSelected = selectedOption == .compress
                self.present(documentPicker, animated: true, completion: nil)
            case .docxToPdf:
                let documentPicker = UIDocumentPickerViewController(documentTypes: ["org.openxmlformats.wordprocessingml.document"], in: .import)
                documentPicker.delegate = self
                documentPicker.allowsMultipleSelection = false
                self.isDocFileSelected = true
                self.present(documentPicker, animated: true, completion: nil)
            }
        }, isFromHome: true))
    }
    
    
   
    func confirmCompressOptions(data:Data!,index:Int){
            let alertController = UIAlertController(
                title: "Successfully compressed PDF",
                message: "You have successfully compressed the PDF file. Please choose to create a new copy or override the original file.",
                preferredStyle: .alert
            )
    
            let yesAction = UIAlertAction(title: "Create Copy", style: .default) { _ in
                self.viewModel.saveCompressedFile(data: data,index: index)
            }
    
        let noAction = UIAlertAction(title: "Override Original", style: .default) { _ in
            self.viewModel.pdfOveride(data: data,index: index)
        }
    
        let cancelAction = UIAlertAction(title: "Cancel", style: .destructive) { _ in
            alertController.dismiss(animated: false)
        }
            alertController.addAction(yesAction)
            alertController.addAction(noAction)
        alertController.addAction(cancelAction)
    
            self.present(alertController, animated: true, completion: nil)
        }
    
    func confirmCompressOptionsMultiple(data:[Int: Data?]){
            let alertController = UIAlertController(
                title: "Successfully compressed PDF",
                message: "You have successfully compressed the PDF files. Please choose to create a new copy or override the original file.",
                preferredStyle: .alert
            )
    
            let yesAction = UIAlertAction(title: "Create Copy", style: .default) { _ in
                self.viewModel.saveCompressedFiles(data: data, isOverride: false)
            }
    
        let noAction = UIAlertAction(title: "Override Original", style: .default) { _ in
            self.viewModel.saveCompressedFiles(data: data, isOverride: true)
        }
    
        let cancelAction = UIAlertAction(title: "Cancel", style: .destructive) { _ in
            alertController.dismiss(animated: false)
        }
            alertController.addAction(yesAction)
            alertController.addAction(noAction)
        alertController.addAction(cancelAction)
    
            self.present(alertController, animated: true, completion: nil)
        }
    
    @IBAction
    func viewTapped(_ sender: Any) {
        view.endEditing(true)
    }
    
    @objc
    func cellTapped(_ sender: UITapGestureRecognizer) {
        viewModel.handlePDFCellTapped(at: sender.view?.tag)
    }
    
    //MARK: - Private Methods
    
    private func pdfTableViewSetup() {
        homeView.pdfTableView.dataSource = self
        homeView.pdfTableView.registerNib(for: PDFTableViewCell.self)
    }
}

//MARK: - UITableViewDataSource Conformance

extension HomeViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.pdfFiles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: PDFTableViewCell = tableView.dequeueCell(for: indexPath)
        cell.showPdfData(pdf: viewModel.pdfFiles[indexPath.row], cellActions: viewModel.cellActionDataSource(at: indexPath))
        cell.cellActionTapped = { [weak self] index in
            guard let self = self else { return }
            viewModel.cellActionButtonTapped(cellIndexPath: indexPath, actionIndex: index,onCompress: {data in
                self.confirmCompressOptions(data: data,index: indexPath.row)
            })
        }
        cell.pdfIconLeadingConstraint.constant = viewModel.isSelection ? 28 : 16
        cell.checkboxIcon.isHidden = !viewModel.isSelection
        cell.checkboxIcon.image = viewModel.selectedPdfs.contains(indexPath.row) ? UIImage(named: "checkbox") : UIImage(named: "uncheckbox")
        cell.actionButton.isHidden = viewModel.isSelection
        cell.cellView.tag = indexPath.row
        cell.cellView.addGestureRecognizer(
            UITapGestureRecognizer(target: self,
                                   action: #selector(cellTapped))
        )
        cell.onCellSelected = { [weak self] in
            guard let self = self else { return }
            if !viewModel.isSelection {
                return
            }
            if viewModel.selectedPdfs.contains(indexPath.row) {
                viewModel.selectedPdfs.removeAll(where: {
                    $0 == indexPath.row
                })
            } else {
                viewModel.selectedPdfs.append(indexPath.row)
            }
            homeView.pdfTableView.reloadData()
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}

//MARK: - PHPickerViewControllerDelegate Conformance

extension HomeViewController: PHPickerViewControllerDelegate {
    
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        showLoader(true)
        let imageItems = results
            .map { $0.itemProvider }
            .filter { $0.canLoadObject(ofClass: UIImage.self) }
        
        let dispatchGroup = DispatchGroup()
        var selectedImages = [GalleryImage]()
        
        for imageItem in imageItems {
            dispatchGroup.enter()
            
            imageItem.loadObject(ofClass: UIImage.self) { image, _ in
                if let image = image as? UIImage {
                    selectedImages.append(GalleryImage(image: image, imageName: imageItem.suggestedName ?? .empty))
                }
                dispatchGroup.leave()
            }
        }
        
        dispatchGroup.notify(queue: .main) {
            self.showLoader(false)
            self.viewModel.imagesReceived(selectedImages)
        }
    }
}

//MARK: - VNDocumentCameraViewControllerDelegate Conformance

extension HomeViewController: VNDocumentCameraViewControllerDelegate {
    
    func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFinishWith scan: VNDocumentCameraScan) {
        dismiss(animated: true)
        
        guard scan.pageCount > 0 else {
            return
        }
        
        let maxImageCount: Int = StorageService.isSubscribed ? .max : 5
        var scannedImages: [GalleryImage] = []
        
        for pageIndex in 0 ..< min(scan.pageCount, maxImageCount) {
            let image = scan.imageOfPage(at: pageIndex)
            scannedImages.append(GalleryImage(image: image, imageName: "ScanImage_\(pageIndex + 1)"))
        }
        
        viewModel.imagesReceived(scannedImages)
    }
}

//MARK: - UIDocumentPickerDelegate Methods

extension HomeViewController: UIDocumentPickerDelegate {
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        let maxImageCount: Int = StorageService.isSubscribed ? .max : 5
        
        if isMergeSelected || isCompressSelected {
            var pdfs: [PDF] = []

            for urlIndex in 0 ..< min(urls.count, maxImageCount) {
                if let imageData = try? Data(contentsOf: urls[urlIndex]),
                   let imageName = urls[urlIndex].lastPathComponent.removingPercentEncoding {
                    pdfs.append(PDF(url: urls[urlIndex], data: imageData, name: imageName, creationDate: Date(), isUnlocked: true))
                }
            }
            viewModel.pdfsToMergeOrCompress.append(contentsOf: pdfs)
            if isMergeSelected {
                viewModel.mergeDocuments()
                isMergeSelected = false
            } else if isCompressSelected {
                viewModel.compressDocuments(onCompress: {
                    self.viewModel.fetchAllPDFs()
                })
                isCompressSelected = false
            }
        } else if isDocFileSelected {
            if let docxURL = urls.first?.absoluteString {
                viewModel.convertDoxToPDf(docxURL: docxURL)
            }
        } else {
            var icloudImages: [GalleryImage] = []
            
            for urlIndex in 0 ..< min(urls.count, maxImageCount) {
                if let imageData = try? Data(contentsOf: urls[urlIndex]),
                   let image = UIImage(data: imageData),
                   let imageName = urls[urlIndex].lastPathComponent.removingPercentEncoding {
                    icloudImages.append(GalleryImage(image: image, imageName: imageName))
                }
            }
            
            viewModel.imagesReceived(icloudImages)
        }
    }
}

//MARK: - UITextFieldDelegate Methods

extension HomeViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
