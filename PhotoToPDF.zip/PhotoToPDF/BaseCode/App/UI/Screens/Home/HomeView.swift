//
//  HomeView.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 12/11/2023.
//

import UIKit

class HomeView: UIView {
    
    //MARK: - Outlets
    
    @IBOutlet weak var recentFilesLabel: UILabel!
    @IBOutlet weak var isProButton: UIButton!
    @IBOutlet weak var favoriteButton: UIButton!
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var filterButton: UIButton!
    @IBOutlet weak var pdfTableView: UITableView!
    @IBOutlet weak var noPDFsLabel: UILabel!
    @IBOutlet weak var addView: UIView!
    @IBOutlet weak var selectButton: UIButton!
    @IBOutlet weak var selectOptionsView: UIView!
    @IBOutlet weak var selectOptionsStackView: UIStackView!
    
    //MARK: - Lifecycle Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        viewSetup()
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        
        [searchView, filterButton].forEach {
            $0.layer.borderColor = Asset.galleryBoulder.color.cgColor
        }
    }
    
    //MARK: - Private Methods
    
    private func viewSetup() {
        recentFilesLabel.text = "Recent Files"
        recentFilesLabel.font = .current(withWeight: .bold, andSize: 28)
        recentFilesLabel.textColor = Asset.capeCodWhite.color
        
        searchView.layer.cornerRadius = 14
        searchView.backgroundColor = Asset.galleryBoulder.color.withAlphaComponent(0.8)
        searchView.layer.borderWidth = 1
        searchView.layer.borderColor = Asset.galleryBoulder.color.cgColor
        
        filterButton.layer.cornerRadius = 8
        filterButton.layer.borderWidth = 1
        filterButton.layer.borderColor = Asset.galleryBoulder.color.cgColor
        
        pdfTableView.contentInset = UIEdgeInsets(
            top: 0,
            left: 0,
            bottom: 80,
            right: 0
        )
        
        searchTextField.font = .current(withWeight: .regular, andSize: 14)
        searchTextField.textColor = Asset.abbeyWhite.color
        let placeholderAttributes: [NSAttributedString.Key: Any] = [
            .foregroundColor: Asset.tunaWhite.color.withAlphaComponent(0.5)
        ]
        searchTextField.attributedPlaceholder = NSAttributedString(string: "Search by file name",
                                                             attributes: placeholderAttributes)
        
        addView.backgroundColor = Asset.dodgarBlue.color
        addView.layer.cornerRadius = addView.frame.width / 2.0
        
        selectOptionsView.layer.borderWidth = 1
        selectOptionsView.layer.borderColor = Asset.greyBorder.color.cgColor
        selectOptionsView.layer.cornerRadius = 12
    }
}
