//
//  PDFReadyView.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 18/12/2023.
//

import UIKit

class PDFReadyView: UIView {
    
    //MARK: - Outlets
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var previewAndNameContainerView: UIView!
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var openFileContainerView: UIView!
    @IBOutlet weak var openFileTitleLabel: UILabel!
    @IBOutlet weak var openFileDescriptionLabel: UILabel!
    
    @IBOutlet weak var saveFileContainerView: UIView!
    @IBOutlet weak var saveFileTitleLabel: UILabel!
    @IBOutlet weak var saveFileDescriptionLabel: UILabel!
    
    @IBOutlet weak var compressFileContainerView: UIView!
    @IBOutlet weak var compressFileTitleLabel: UILabel!
    @IBOutlet weak var compressFileDescriptionLabel: UILabel!
    
    @IBOutlet weak var shareFileContainerView: UIView!
    @IBOutlet weak var shareFileTitleLabel: UILabel!
    @IBOutlet weak var shareFileDescriptionLabel: UILabel!
    
    @IBOutlet weak var protectFileContainerView: UIView!
    @IBOutlet weak var protectFileTitleLabel: UILabel!
    @IBOutlet weak var protectFileDescriptionLabel: UILabel!
    
    @IBOutlet weak var renameFileContainerView: UIView!
    @IBOutlet weak var renameFileTitleLabel: UILabel!
    @IBOutlet weak var renameFileDescriptionLabel: UILabel!
    
    @IBOutlet weak var goToHomeContainerView: UIView!
    @IBOutlet weak var goToHomeTitleLabel: UILabel!
    @IBOutlet weak var goToHomeDescriptionLabel: UILabel!
    
    @IBOutlet weak var mergeFileContainerView: UIView!
    @IBOutlet weak var mergeFileTitleLabel: UILabel!
    @IBOutlet weak var mergeFileDescriptionLabel: UILabel!
    
    //MARK: - Override Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        initialSetup()
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        
        previewAndNameContainerView.layer.borderColor = Asset.mercuryShark.color.cgColor
        [openFileContainerView, saveFileContainerView,compressFileContainerView, mergeFileContainerView, shareFileContainerView,
         protectFileContainerView, renameFileContainerView, goToHomeContainerView].forEach {
            $0?.layer.borderColor = Asset.mercuryShark.color.cgColor
        }
    }
    
    //MARK: - Private Methods
    
    private func initialSetup() {
        titleLabel.text = "Your document is ready!"
        titleLabel.font = .current(withWeight: .bold, andSize: 20)
        titleLabel.textColor = Asset.abbeyWhite.color
        
        previewAndNameContainerView.layer.cornerRadius = 12
        previewAndNameContainerView.layer.borderWidth = 1
        previewAndNameContainerView.layer.borderColor = Asset.mercuryShark.color.cgColor
        
        nameLabel.font = .current(withWeight: .regular, andSize: 16)
        nameLabel.textColor = Asset.abbeyWhite.color
        
        [openFileContainerView, saveFileContainerView,compressFileContainerView, mergeFileContainerView, shareFileContainerView,
         protectFileContainerView, renameFileContainerView, goToHomeContainerView].forEach {
            $0?.layer.cornerRadius = 12
            $0?.layer.borderWidth = 1
            $0?.layer.borderColor = Asset.mercuryShark.color.cgColor
            $0?.backgroundColor = Asset.whiteBlack.color
        }
        
        [openFileTitleLabel, saveFileTitleLabel,compressFileTitleLabel, mergeFileTitleLabel, shareFileTitleLabel,
         protectFileTitleLabel, renameFileTitleLabel, goToHomeTitleLabel].forEach {
            $0?.font = .current(withWeight: .medium, andSize: 16)
            $0?.textColor = Asset.abbeyWhite.color
        }
        
        [openFileDescriptionLabel, saveFileDescriptionLabel,compressFileDescriptionLabel, mergeFileDescriptionLabel, shareFileDescriptionLabel,
         protectFileDescriptionLabel, renameFileDescriptionLabel, goToHomeDescriptionLabel].forEach {
            $0?.font = .current(withWeight: .regular, andSize: 14)
            $0?.textColor = Asset.abbeyWhite.color.withAlphaComponent(0.6)
        }
        
        openFileTitleLabel.text = "Open File"
        openFileDescriptionLabel.text = "Open your file"
        
        saveFileTitleLabel.text = "Save"
        saveFileDescriptionLabel.text = "Save your file to device"
        
        compressFileTitleLabel.text = "Compress"
        compressFileDescriptionLabel.text = "Reduce file size"
        
        shareFileTitleLabel.text = "Share"
        shareFileDescriptionLabel.text = "Save your file to others"
        
        protectFileDescriptionLabel.text = "Password protect your file"
        
        renameFileTitleLabel.text = "Rename"
        renameFileDescriptionLabel.text = "Rename your file"
        
        goToHomeTitleLabel.text = "Home"
        goToHomeDescriptionLabel.text = "Go to home"
        
        mergeFileTitleLabel.text = "Merge File"
        mergeFileDescriptionLabel.text = "Merge with other pdf files"
    }
}
