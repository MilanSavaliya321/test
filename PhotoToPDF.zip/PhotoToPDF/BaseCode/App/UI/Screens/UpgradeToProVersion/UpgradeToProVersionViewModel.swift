//
//  UpgradeToProVersionViewModel.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 24/12/2023.
//

import Foundation

class UpgradeToProVersionViewModel: ViewModel {
    
    //MARK: - Methods
    
    func handleBackTapped() {
        router.pop()
    }
}
