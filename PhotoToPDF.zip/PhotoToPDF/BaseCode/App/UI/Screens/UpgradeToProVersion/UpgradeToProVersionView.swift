//
//  UpgradeToProVersionView.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 24/12/2023.
//

import UIKit

class UpgradeToProVersionView: UIView {
    
    //MARK: - Outlets
    @IBOutlet weak var diamondImageView: UIImageView!
    
    @IBOutlet weak var subscriptionTableView: UITableView!
    @IBOutlet weak var subscriptionTableViewHeight: NSLayoutConstraint!
    
    private var gradientLayer: CAGradientLayer?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        
        
        diamondImageView.alpha = 0.2
        
    }
    
    func addGradient() {
        if let gradientLayer = gradientLayer {
            self.removeGradient(gradientLayer: gradientLayer)
            self.gradientLayer = self.addGradient(
                withColor: [Asset.dodgarBlue.color, Asset.lightBlue.color, Asset.lightBlue.color],
                withDirection: .vertical)
        } else {
            self.gradientLayer = self.addGradient(
                withColor: [Asset.dodgarBlue.color, Asset.lightBlue.color, Asset.lightBlue.color],
                withDirection: .vertical)
        }
    }
}
