//
//  SettingsHeaderView.swift
//  BaseCode
//
//  Created by Soliton on 26/02/2024.
//

import UIKit

class SettingsHeaderView: UIView {

    @IBOutlet weak var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        titleLabel.font = .current(withWeight: .semibold, andSize: 16)
        titleLabel.textColor = Asset.abbeyWhite.color.withAlphaComponent(0.8)
    }
}
