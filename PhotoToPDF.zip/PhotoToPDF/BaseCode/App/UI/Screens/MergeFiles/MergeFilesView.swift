//
//  MergeFilesView.swift
//  BaseCode
//
//  Created by Soliton on 17/02/2024.
//

import UIKit

class MergeFilesView: UIView {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addMoreButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        tableView.separatorStyle = .none
        
        addMoreButton.layer.cornerRadius = 12
        addMoreButton.layer.borderWidth = 1
        addMoreButton.layer.borderColor = Asset.dodgarBlue.color.cgColor
        
        addMoreButton.setTitle("Add More", for: .normal)
        addMoreButton.titleLabel?.font = .current(withWeight: .semibold, andSize: 16)
        addMoreButton.setTitleColor(Asset.dodgarBlue.color, for: .normal)
    }
}
