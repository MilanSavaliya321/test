//
//  MergeFilesViewModel.swift
//  BaseCode
//
//  Created by Soliton on 17/02/2024.
//

import Combine
import Foundation
import UIKit

class MergeFilesViewModel: ViewModel {

    //MARK: - Properties
    
    @Published var selectedPdfs: [PDF] = []
    
    //MARK: - Initializers
    
    init(pdfs: [PDF]) {
        self.selectedPdfs = pdfs
    }
    
    //MARK: - Methods
    
    func handleBackTapped() {
        router.pop()
    }
    
    func handleNextButtonTapped() {
        guard !selectedPdfs.isEmpty else {
            return
        }
        var allImages = [UIImage]()
        
        selectedPdfs.forEach({
            let images = PdfIUtils.extractImagesFromPDF(pdfURL: $0.url)
            allImages.append(contentsOf: images)
        })
        var galleryImages = [GalleryImage]()
        for (index, image) in allImages.enumerated() {
            galleryImages.append(GalleryImage(image: image, imageName: "scanImage_\(index + 1)"))
        }
        router.append(.pdfOptions(images: galleryImages, isFromMerge: true))
    }
}

