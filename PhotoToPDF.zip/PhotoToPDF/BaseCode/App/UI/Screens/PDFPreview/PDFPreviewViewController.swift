//
//  PDFPreviewViewController.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 13/11/2023.
//

import UIKit

class PDFPreviewViewController: ViewController<PDFPreviewViewModel> {
    
    //MARK: - Outlets
    
    @IBOutlet var pdfPreviewView: PDFPreviewView!
    
    //MARK: - Override Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigationItems()
        showPdf()
    }
    
    //MARK: - Action Methods
    
    @IBAction
    func shareButtonTapped(_ sender: Any) {
        let activityViewController = UIActivityViewController(
            activityItems: [viewModel.pdfData],
            applicationActivities: nil
        )
        activityViewController.popoverPresentationController?.sourceView = view
        present(activityViewController, animated: true, completion: nil)
    }
    
    @objc
    func backButtonTapped() {
        viewModel.handleBackTapped()
    }
    
    //MARK: - Private Methods
    
    private func setupNavigationItems() {
        title = "Preview"
        navigationController?.navigationBar.titleTextAttributes = [
            .foregroundColor: Asset.capeCodWhite.color,
            .font: UIFont.current(withWeight: .bold, andSize: 20)
        ]
        
        let backButton = UIBarButtonItem(
            image: Asset.backArrow.image,
            style: .plain,
            target: self,
            action: #selector(backButtonTapped)
        )
        backButton.tintColor = Asset.capeCodWhite.color
        navigationItem.leftBarButtonItem = backButton
        navigationItem.hidesBackButton = true
    }
    
    private func showPdf() {
        pdfPreviewView.pdfView.load(
            viewModel.pdfData,
            mimeType: "application/pdf",
            characterEncodingName: "utf-8",
            baseURL: NSURL() as URL
        )
    }
}
