//
//  SplashViewController.swift
//  BaseCode
//
//  Created by  on 27/07/2023.
//

import MobileCoreServices
import Photos
import PhotosUI
import UIKit
import VisionKit

class PhotosViewController: ViewController<PhotosViewModel> {
    
    //MARK: - Outlets
    
    @IBOutlet var photosView: PhotosView!
    
    //MARK: - Properties
    
    private let spacing: CGFloat = 16
    private let spacingBetweenCells: CGFloat = 20
    private var numberOfItemsPerRow: CGFloat {
        let availableSpace = photosView.gridCollectionView.frame.width - 2 * spacing
        return (availableSpace + spacingBetweenCells) / 120
    }
    private var selectedOption: PhotosView.SelectionTab = .grid
    
    //MARK: - Overriden Methods

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupNavigationItems()
        gridCollectionViewSetup()
        listTableViewSetup()
        setSelectedTab(selectedOption)
    }
    
    override func setupBinding() {
        viewModel
            .$images
            .receive(on: DispatchQueue.main)
            .sink { [weak self] images in
                guard let self = self else {
                    return
                }
                switch selectedOption {
                case .grid:
                    photosView.gridCollectionView.reloadData()
                case .list:
                    photosView.listTableView.reloadData()
                }
                photosView.addMoreButton.isHidden = !StorageService.isSubscribed && images.count >= 5
                photosView.noPhotosLabel.isHidden = !images.isEmpty
                navigationItem.rightBarButtonItem?.isEnabled = !images.isEmpty
            }
            .store(in: &bag)
    }

    //MARK: - Action Methods
    
    @IBAction
    func gridButtonTapped(_ sender: Any) {
        guard selectedOption != .grid else {
            return
        }
        setSelectedTab(.grid)
    }
    
    @IBAction
    func listButtonTapped(_ sender: Any) {
        guard selectedOption != .list else {
            return
        }
        setSelectedTab(.list)
    }
    
    @IBAction
    func addMoreButtonTapped(_ sender: Any) {
        viewModel.router.showSheet(.photosSelection(selectionClosure: { selectedOption in
            switch selectedOption {
            case .scan:
                let imageScanner = VNDocumentCameraViewController()
                imageScanner.delegate = self
                self.present(imageScanner, animated: true)
            case .icloud:
                let documentPicker = UIDocumentPickerViewController(documentTypes: [kUTTypeImage as String], in: .import)
                documentPicker.delegate = self
                documentPicker.allowsMultipleSelection = true
                self.present(documentPicker, animated: true, completion: nil)
            case .library:
                var configuration = PHPickerConfiguration()
                if StorageService.isSubscribed {
                    configuration.selectionLimit = .max
                } else {
                    configuration.selectionLimit = 5 - self.viewModel.images.count
                }
                configuration.filter = .images
                
                let picker = PHPickerViewController(configuration: configuration)
                picker.delegate = self
                self.present(picker, animated: true, completion: nil)
            default:
                break
            }
        }, isFromHome: false))
    }
    
    @objc
    private func deleteImageButtonTapped(_ sender: UIButton) {
        let imageIndex = sender.tag
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)

        let deleteAction = UIAlertAction(title: "Remove Photo", style: .destructive) { (action) in
            self.viewModel.images.remove(at: imageIndex)
        }
        alertController.addAction(deleteAction)

        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)

        if let popoverController = alertController.popoverPresentationController {
            popoverController.sourceView = view
            popoverController.sourceRect = view.bounds
        }

        present(alertController, animated: true, completion: nil)
    }
    
    @objc
    func backButtonTapped() {
        let alertController = UIAlertController(
            title: "You'll lose your selection",
            message: "Are you sure you want to quit?",
            preferredStyle: .alert
        )
        
        let yesAction = UIAlertAction(title: "Yes", style: .destructive) { _ in
            self.viewModel.handleBackTapped()
        }
        
        let noAction = UIAlertAction(title: "No", style: .default) { _ in }
        
        alertController.addAction(yesAction)
        alertController.addAction(noAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
    @objc
    func nextButtonTapped() {
        viewModel.handleNextButtonTapped()
    }
    
    @objc
    func handleImageLongPressed(_ gesture: UILongPressGestureRecognizer) {
        guard let targetImageIndex = gesture.view?.tag else {
            return
        }
        switch gesture.state {
        case .began:
            photosView.gridCollectionView.beginInteractiveMovementForItem(at: IndexPath(row: targetImageIndex, section: 0))
        case .changed:
            photosView.gridCollectionView.updateInteractiveMovementTargetPosition(gesture.location(in: photosView.gridCollectionView))
        case .ended:
            photosView.gridCollectionView.endInteractiveMovement()
        default:
            photosView.gridCollectionView.cancelInteractiveMovement()
        }
    }
    
    //MARK: - Methods
    
    private func setupNavigationItems() {
        title = "Photos"
        navigationController?.navigationBar.titleTextAttributes = [
            .foregroundColor: Asset.capeCodWhite.color,
            .font: UIFont.current(withWeight: .bold, andSize: 20)
        ]
        
        let nextButton = UIBarButtonItem(
            title: "Next",
            style: .plain,
            target: self,
            action: #selector(nextButtonTapped)
        )
        nextButton.setTitleTextAttributes(
            [
                .font: UIFont.current(withWeight: .semibold, andSize: 16),
                .foregroundColor: Asset.dodgarBlue.color
            ],
            for: .normal
        )
        navigationItem.rightBarButtonItem = nextButton
        
        let backButton = UIBarButtonItem(
            image: Asset.backArrow.image,
            style: .plain,
            target: self,
            action: #selector(backButtonTapped)
        )
        backButton.tintColor = Asset.capeCodWhite.color
        navigationItem.leftBarButtonItem = backButton
        navigationItem.hidesBackButton = true
    }
    
    private func gridCollectionViewSetup() {
        photosView.gridCollectionView.registerNib(for: PhotoCollectionViewCell.self)
        photosView.gridCollectionView.dataSource = self
        photosView.gridCollectionView.delegate = self
        photosView.gridCollectionView.contentInset.top = spacing
        photosView.gridCollectionView.contentInset.left = spacing
        photosView.gridCollectionView.contentInset.right = spacing
    }
    
    private func listTableViewSetup() {
        photosView.listTableView.registerNib(for: PhotoTableViewCell.self)
        photosView.listTableView.dataSource = self
        photosView.listTableView.delegate = self
        photosView.listTableView.dragDelegate = self
        photosView.listTableView.dragInteractionEnabled = true
    }
    
    private func sizeForItem(_ collectionView: UICollectionView) -> CGSize {
        let totalSpacing = (2 * spacing) + ((numberOfItemsPerRow - 1) * spacingBetweenCells)
        let width = (photosView.gridCollectionView.frame.width - totalSpacing) / numberOfItemsPerRow
        let height = ((width - 10) * 1.44) + 7
        return CGSize(width: width, height: height)
    }
    
    private func setSelectedTab(_ tab: PhotosView.SelectionTab) {
        selectedOption = tab
        photosView.setSelectionTab(tab)
        switch selectedOption {
        case .grid:
            photosView.listTableView.isHidden = true
            photosView.gridCollectionView.isHidden = false
            photosView.gridCollectionView.reloadData()
        case .list:
            photosView.gridCollectionView.isHidden = true
            photosView.listTableView.isHidden = false
            photosView.listTableView.reloadData()
        }
    }
}

//MARK: - UICollectionView Methods

extension PhotosViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        viewModel.images.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell: PhotoCollectionViewCell = collectionView.dequeueCell(for: indexPath)
        cell.imageView.isUserInteractionEnabled = true
        cell.imageView.tag = indexPath.row
        cell.imageView.addGestureRecognizer(
            UILongPressGestureRecognizer(target: self,
                                         action: #selector(handleImageLongPressed))
        )
        cell.deleteButton.tag = indexPath.row
        cell.deleteButton.addTarget(
            self,
            action: #selector(deleteImageButtonTapped),
            for: .touchUpInside
        )
        cell.imageView.image = viewModel.images[indexPath.row].image
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        sizeForItem(collectionView)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        spacingBetweenCells
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        spacingBetweenCells
    }
    
    func collectionView(_ collectionView: UICollectionView, canMoveItemAt indexPath: IndexPath) -> Bool {
        true
    }
    
    func collectionView(_ collectionView: UICollectionView, moveItemAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let mover = viewModel.images.remove(at: sourceIndexPath.row)
        viewModel.images.insert(mover, at: destinationIndexPath.row)
    }
}

//MARK: - UITableView Methods

extension PhotosViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.images.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: PhotoTableViewCell = tableView.dequeueCell(for: indexPath)
        cell.photoImageView.image = viewModel.images[indexPath.row].image
        cell.nameLabel.text = viewModel.images[indexPath.row].imageName
        cell.actionButton.tag = indexPath.row
        cell.actionButton.addTarget(
            self,
            action: #selector(deleteImageButtonTapped),
            for: .touchUpInside
        )
        return cell
    }
}

extension PhotosViewController: UITableViewDragDelegate {
    
    func tableView(_ tableView: UITableView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        let dragItem = UIDragItem(itemProvider: NSItemProvider())
        dragItem.localObject = viewModel.images[indexPath.row]
        return [ dragItem ]
    }
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let mover = viewModel.images.remove(at: sourceIndexPath.row)
        viewModel.images.insert(mover, at: destinationIndexPath.row)
    }
}

//MARK: - PHPickerViewControllerDelegate Conformance

extension PhotosViewController: PHPickerViewControllerDelegate {
    
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        showLoader(true)
        let imageItems = results
            .map { $0.itemProvider }
            .filter { $0.canLoadObject(ofClass: UIImage.self) }
        
        let dispatchGroup = DispatchGroup()
        var selectedImages = [GalleryImage]()
        
        for imageItem in imageItems {
            dispatchGroup.enter()
            
            imageItem.loadObject(ofClass: UIImage.self) { image, _ in
                if let image = image as? UIImage {
                    selectedImages.append(GalleryImage(image: image, imageName: imageItem.suggestedName ?? .empty))
                }
                dispatchGroup.leave()
            }
        }
        
        dispatchGroup.notify(queue: .main) {
            self.showLoader(false)
            self.viewModel.images.append(contentsOf: selectedImages)
        }
    }
}

//MARK: - VNDocumentCameraViewControllerDelegate Conformance

extension PhotosViewController: VNDocumentCameraViewControllerDelegate {
    
    func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFinishWith scan: VNDocumentCameraScan) {
        dismiss(animated: true)
        
        guard scan.pageCount > 0 else {
            return
        }
        
        let maxImageCount: Int = StorageService.isSubscribed ? .max : 5 - viewModel.images.count
        var scannedImages: [GalleryImage] = []
        
        for pageIndex in 0 ..< min(scan.pageCount, maxImageCount) {
            let image = scan.imageOfPage(at: pageIndex)
            scannedImages.append(GalleryImage(image: image, imageName: "ScanImage_\(pageIndex + 1)"))
        }
        
        viewModel.images.append(contentsOf: scannedImages)
    }
}

//MARK: - UIDocumentPickerDelegate Methods

extension PhotosViewController: UIDocumentPickerDelegate {
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        let maxImageCount: Int = StorageService.isSubscribed ? .max : 5 - viewModel.images.count
        
        var icloudImages: [GalleryImage] = []
        
        for urlIndex in 0 ..< min(urls.count, maxImageCount) {
            if let imageData = try? Data(contentsOf: urls[urlIndex]),
               let image = UIImage(data: imageData),
               let imageName = urls[urlIndex].lastPathComponent.removingPercentEncoding {
                icloudImages.append(GalleryImage(image: image, imageName: imageName))
            }
        }
        
        viewModel.images.append(contentsOf: icloudImages)
    }
}
