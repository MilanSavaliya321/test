//
//  SplashViewModel.swift
//  BaseCode
//
//  Created by  on 27/07/2023.
//

import Combine
import Foundation
import UIKit

class PhotosViewModel: ViewModel {

    //MARK: - Properties
    
    @Published var images: [GalleryImage] = []
    
    //MARK: - Initializers
    
    init(images: [GalleryImage]) {
        self.images = images
    }
    
    //MARK: - Methods
    
    func handleBackTapped() {
        router.pop()
    }
    
    func handleNextButtonTapped() {
        guard !images.isEmpty else {
            return
        }
        router.append(.pdfOptions(images: images, isFromMerge: false))
    }
}
