//
//  FilterViewController.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 10/12/2023.
//

import UIKit

class FilterViewController: ViewController<FilterViewModel> {
    
    //MARK: - Outlets
    
    @IBOutlet var filterView: FilterView!
    
    //MARK: - Properties
    
    let cellHeight: CGFloat = 48

    //MARK: - Override Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configurePresentation()
        tableViewSetup()
    }
    
    override func setupBinding() {
        viewModel
            .$selectedOption
            .sink { [weak self] _ in
                guard let self = self else { return }
                filterView.sortTableView.reloadData()
            }
            .store(in: &bag)
    }
    
    @IBAction
    func handleApplyButtonTapped(_ sender: Any) {
        viewModel.handleApplyButtonTapped()
    }
    
    @IBAction
    func resetButtonTapped(_ sender: Any) {
        viewModel.handleResetButtonTapped()
    }
    
    //MARK: - Private Methods
    
    private func configurePresentation() {
        let presentationController = presentationController as? UISheetPresentationController
        presentationController?.detents = [.custom(resolver: { _ in
            220 + (CGFloat(SortOption.allCases.count) * self.cellHeight)
        })]
    }
    
    private func tableViewSetup() {
        filterView.sortTableView.dataSource = self
        filterView.sortTableView.delegate = self
        filterView.sortTableView.registerNib(for: SortTableViewCell.self)
    }
}

//MARK: - UITableView Methods

extension FilterViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        SortOption.allCases.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: SortTableViewCell = tableView.dequeueCell(for: indexPath)
        cell.titleLabel.text = SortOption(rawValue: indexPath.row)?.title
        cell.titleLabel.textColor = viewModel.selectedOption.rawValue == indexPath.row ? Asset.capeCodWhite.color : Asset.nevadaBoulder.color
        cell.isSelectedImageView.isHidden = viewModel.selectedOption.rawValue != indexPath.row
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let optionTapped = SortOption(rawValue: indexPath.row),
              optionTapped != viewModel.selectedOption else {
            return
        }
        viewModel.selectedOption = optionTapped
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        cellHeight
    }
}
