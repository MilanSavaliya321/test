//
//  FilterView.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 10/12/2023.
//

import UIKit

class FilterView: UIView {
    
    //MARK: - Outlets
    
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var lineView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var sortTableView: UITableView!
    @IBOutlet weak var applyButton: UIButton!
    @IBOutlet weak var resetButton: UIButton!
    
    //MARK: - Override Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        initialSetup()
    }
    
    //MARK: - Private Methods
    
    private func initialSetup() {
        backgroundColor = .clear
        
        contentView.backgroundColor = Asset.whiteBlack.color
        contentView.clipsToBounds = true
        contentView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        contentView.layer.cornerRadius = 16
        
        lineView.layer.cornerRadius = lineView.frame.height / 2
        lineView.backgroundColor = Asset.osloGrayEdward.color
        
        titleLabel.text = "Sort"
        titleLabel.font = .current(withWeight: .semibold, andSize: 18)
        titleLabel.textColor = Asset.abbeyWhite.color
        
        sortTableView.backgroundColor = Asset.whiteBlack.color
        
        applyButton.layer.cornerRadius = 12
        applyButton.setTitle("Apply", for: .normal)
        applyButton.titleLabel?.font = .current(withWeight: .medium, andSize: 16)
        applyButton.setTitleColor(Asset.dodgarBlue.color, for: .normal)
        applyButton.backgroundColor = Asset.albasterShark.color
        
        resetButton.setTitle("Reset", for: .normal)
        resetButton.titleLabel?.font = .current(withWeight: .semibold, andSize: 16)
        resetButton.setTitleColor(Asset.nevadaBoulder.color, for: .normal)
    }
}
