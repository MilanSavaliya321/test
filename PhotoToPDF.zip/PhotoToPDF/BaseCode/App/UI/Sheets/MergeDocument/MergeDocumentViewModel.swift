//
//  MergeDocumentViewModel.swift
//  BaseCode
//
//  Created by Soliton on 18/02/2024.
//

import Foundation

class MergeDocumentViewModel: ViewModel {
    
    //MARK: - Enum
    
    enum DocumentSelection {
        case recent
        case files
    }
    
    //MARK: - Properties
    
    var selectionClosure: ((_ selectedOption: DocumentSelection) -> Void)
    
    //MARK: - Initializers
    
    init(selectionClosure: @escaping ((_ selectedOption: DocumentSelection) -> Void)) {
        self.selectionClosure = selectionClosure
    }
    
    //MARK: - Methods

    func handleSelectionViewTapped(_ selection: DocumentSelection) {
        router.dismiss()
        selectionClosure(selection)
    }
    
    func handleCancelButtonTapped() {
        router.dismiss()
    }
}

