//
//  MergeDocumentViewController.swift
//  BaseCode
//
//  Created by Soliton on 18/02/2024.
//

import UIKit

class MergeDocumentViewController: ViewController<MergeDocumentViewModel> {

    //MARK: - Override Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configurePresentation()
    }
    
    //MARK: - Action Methods
    
    @IBAction
    func cancelButtonTapped(_ sender: Any) {
        viewModel.handleCancelButtonTapped()
    }
    
    @IBAction
    func openRecentTapped(_ sender: Any) {
        viewModel.handleSelectionViewTapped(.recent)
    }
    
    @IBAction
    func openFilesTapped(_ sender: Any) {
        viewModel.handleSelectionViewTapped(.files)
    }
    
    //MARK: - Private Methods
    
    private func configurePresentation() {
        let presentationController = presentationController as? UISheetPresentationController
        presentationController?.detents = [.custom(resolver: { _ in
            311
        })]
    }

}
