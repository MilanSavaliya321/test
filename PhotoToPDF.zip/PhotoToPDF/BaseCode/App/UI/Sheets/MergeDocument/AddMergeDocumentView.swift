//
//  AddMergeDocumentView.swift
//  BaseCode
//
//  Created by Soliton on 18/02/2024.
//

import UIKit

class AddMergeDocumentView: UIView {

    //MARK: - Outlets
    
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var lineView: UIView!
    @IBOutlet weak var cancelButton: UIButton!
    
    //MARK: - Override Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        initialSetup()
    }
    
    //MARK: - Private Methods
    
    private func initialSetup() {
        backgroundColor = .clear
        
        contentView.backgroundColor = Asset.whiteBlack.color
        contentView.clipsToBounds = true
        contentView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        contentView.layer.cornerRadius = 16
        
        lineView.layer.cornerRadius = lineView.frame.height / 2
        lineView.backgroundColor = Asset.osloGrayEdward.color
        
        cancelButton.setTitle("Cancel", for: .normal)
        cancelButton.layer.cornerRadius = 12
        cancelButton.layer.borderWidth = 1
        cancelButton.layer.borderColor = Asset.dodgarBlue.color.cgColor
        cancelButton.titleLabel?.font = .current(withWeight: .semibold, andSize: 16)
        cancelButton.setTitleColor(Asset.dodgarBlue.color, for: .normal)
        cancelButton.backgroundColor = Asset.whiteBlack.color
    }
}
