//
//  SetPasswordViewController.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 17/12/2023.
//

import UIKit

class SetPasswordViewController: ViewController<SetPasswordViewModel> {
    
    //MARK: - Outlets
    
    @IBOutlet var setPasswordView: SetPasswordView!
    
    //MARK: - Override Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configurePresentation()
        setPasswordView.passwordProtectTextField.delegate = self
        setPasswordView.reEnterPasswordTextField.delegate = self
    }
    
    override func setupBinding() {
        super.setupBinding()
        
        viewModel
            .$passwordText
            .sink { [weak self] password in
                guard let self = self else { return }
                setPasswordView.passwordProtectTextField.text = password
            }
            .store(in: &bag)
        
        viewModel
            .$isPasswordVisibile
            .sink { [weak self] isVisible in
                guard let self = self else { return }
                setPasswordView.passwordProtectTextField.isSecureTextEntry = !isVisible
                setPasswordView.passwordProtectVisibilityButton.setImage(
                    isVisible ? Asset.unLockEye.image : Asset.lockEye.image,
                    for: .normal
                )
            }
            .store(in: &bag)
        
        viewModel
            .$reEnterPasswordText
            .sink { [weak self] password in
                guard let self = self else { return }
                setPasswordView.reEnterPasswordTextField.text = password
            }
            .store(in: &bag)
        
        viewModel
            .$isReEnterPasswordVisibile
            .sink { [weak self] isVisible in
                guard let self = self else { return }
                setPasswordView.reEnterPasswordTextField.isSecureTextEntry = !isVisible
                setPasswordView.reEnterPasswordVisibilityButton.setImage(
                    isVisible ? Asset.unLockEye.image : Asset.lockEye.image,
                    for: .normal
                )
            }
            .store(in: &bag)
        
        setPasswordView
            .passwordProtectTextField
            .textDidChangePublisher
            .compactMap { $0 }
            .assign(to: \.passwordText, on: viewModel)
            .store(in: &bag)
        
        setPasswordView
            .reEnterPasswordTextField
            .textDidChangePublisher
            .compactMap { $0 }
            .assign(to: \.reEnterPasswordText, on: viewModel)
            .store(in: &bag)
    }
    
    //MARK: - Action Methods
    
    @IBAction
    func passwordProtectVisibiltyButtonTapped(_ sender: Any) {
        viewModel.handlePasswordProtectVisibiltyButtonTapped()
    }
    
    @IBAction
    func reEnterPasswordVisibiltyButtonTapped(_ sender: Any) {
        viewModel.handleReEnterPasswordVisibiltyButtonTapped()
    }
    
    @IBAction
    func applyButtonTapped(_ sender: Any) {
        view.endEditing(true)
        viewModel.handleApplyButtonTapped()
    }
    
    @IBAction
    func discardButtonTapped(_ sender: Any) {
        view.endEditing(true)
        viewModel.handleDiscardButtonTapped()
    }
    
    //MARK: - Private Methods
    
    private func configurePresentation() {
        let presentationController = presentationController as? UISheetPresentationController
        presentationController?.detents = [.custom(resolver: { _ in
            400
        })]
    }
}

//MARK: - UITextFieldDelegate Methods

extension SetPasswordViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == setPasswordView.passwordProtectTextField {
            setPasswordView.reEnterPasswordTextField.becomeFirstResponder()
        } else if textField == setPasswordView.reEnterPasswordTextField {
            applyButtonTapped(textField)
        }
        return true
    }
}
