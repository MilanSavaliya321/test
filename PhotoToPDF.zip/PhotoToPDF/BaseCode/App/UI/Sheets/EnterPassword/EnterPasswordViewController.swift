//
//  EnterPasswordViewController.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 17/12/2023.
//

import UIKit

class EnterPasswordViewController: ViewController<EnterPasswordViewModel> {
    
    //MARK: - Outlets
    
    @IBOutlet var enterPasswordView: EnterPasswordView!
    
    //MARK: - Override Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configurePresentation()
        enterPasswordView.passwordProtectTextField.delegate = self
    }
    
    override func setupBinding() {
        super.setupBinding()
        
        viewModel
            .$passwordText
            .sink { [weak self] password in
                guard let self = self else { return }
                enterPasswordView.passwordProtectTextField.text = password
            }
            .store(in: &bag)
        
        viewModel
            .$isPasswordVisibile
            .sink { [weak self] isVisible in
                guard let self = self else { return }
                enterPasswordView.passwordProtectTextField.isSecureTextEntry = !isVisible
                enterPasswordView.passwordProtectVisibilityButton.setImage(
                    isVisible ? Asset.unLockEye.image : Asset.lockEye.image,
                    for: .normal
                )
            }
            .store(in: &bag)
        
        enterPasswordView
            .passwordProtectTextField
            .textDidChangePublisher
            .compactMap { $0 }
            .assign(to: \.passwordText, on: viewModel)
            .store(in: &bag)
    }
    
    //MARK: - Action Methods
    
    @IBAction
    func passwordProtectVisibiltyButtonTapped(_ sender: Any) {
        viewModel.handlePasswordProtectVisibiltyButtonTapped()
    }
    
    @IBAction
    func applyButtonTapped(_ sender: Any) {
        viewModel.handleApplyButtonTapped()
    }
    
    @IBAction
    func discardButtonTapped(_ sender: Any) {
        viewModel.handleDiscardButtonTapped()
    }
    
    //MARK: - Private Methods
    
    private func configurePresentation() {
        let presentationController = presentationController as? UISheetPresentationController
        presentationController?.detents = [.custom(resolver: { _ in
            315
        })]
    }
}

//MARK: - UITextFieldDelegate Methods

extension EnterPasswordViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        viewModel.handleApplyButtonTapped()
        return true
    }
}
