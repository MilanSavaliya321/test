//
//  EnterPasswordViewModel.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 17/12/2023.
//

import Foundation

class EnterPasswordViewModel: ViewModel {
    
    //MARK: - Properties
    
    @Published var passwordText: String = .empty {
        didSet {
            if passwordText.count > maxLimit {
                alert = "Password maximum limit is \(maxLimit)"
                passwordText = String(passwordText.prefix(maxLimit))
            }
        }
    }
    @Published var isPasswordVisibile: Bool = false
    var selectedPassword: ((_ password: String) -> Void)
    private let maxLimit: Int = 30
    
    //MARK: - Initializers
    
    init(selectedPassword: @escaping ((_ password: String) -> Void)) {
        self.selectedPassword = selectedPassword
    }
    
    //MARK: - Methods
    
    func handlePasswordProtectVisibiltyButtonTapped() {
        isPasswordVisibile.toggle()
    }
    
    func handleApplyButtonTapped() {
        passwordText = passwordText.trimmingCharacters(in: .whitespaces)
        
        guard !passwordText.isEmpty else {
            alert = "Password Can't be empty"
            return
        }
        router.dismiss()
        selectedPassword(passwordText)
        
    }
    
    func handleDiscardButtonTapped() {
        router.dismiss()
    }
}
