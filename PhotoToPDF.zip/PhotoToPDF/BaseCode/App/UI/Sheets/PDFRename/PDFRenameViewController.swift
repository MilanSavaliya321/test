//
//  PDFRenameViewController.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 16/12/2023.
//

import UIKit

class PDFRenameViewController: ViewController<PDFRenameViewModel> {
    
    //MARK: - Outlets
    
    @IBOutlet var pdfRenameView: PDFRenameView!
    
    //MARK: - Override Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configurePresentation()
        pdfRenameView.pdfNameTextField.delegate = self
    }
    
    override func setupBinding() {
        super.setupBinding()

        viewModel
            .$pdfName
            .sink { [weak self] name in
                guard let self = self else {
                    return
                }
                pdfRenameView.pdfNameTextField.text = name
            }
            .store(in: &bag)
        
        pdfRenameView
            .pdfNameTextField
            .textDidChangePublisher
            .compactMap { $0 }
            .assign(to: \.pdfName, on: viewModel)
            .store(in: &bag)
    }
    
    //MARK: - Action Methods
    
    @IBAction
    func applyButtonTapped(_ sender: Any) {
        viewModel.handleApplyButtonTapped()
    }
    
    @IBAction
    func discardButtonTapped(_ sender: Any) {
        viewModel.handleDiscardButtonTapped()
    }
    
    //MARK: - Private Methods
    
    private func configurePresentation() {
        let presentationController = presentationController as? UISheetPresentationController
        presentationController?.detents = [.custom(resolver: { _ in
            315
        })]
    }
}

//MARK: - UITextFieldDelegate Methods

extension PDFRenameViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        viewModel.handleApplyButtonTapped()
        return true
    }
}
