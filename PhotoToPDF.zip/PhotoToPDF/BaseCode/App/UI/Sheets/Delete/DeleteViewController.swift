//
//  DeleteViewController.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 17/12/2023.
//

import UIKit

class DeleteViewController: ViewController<DeleteViewModel> {
    
    //MARK: - Outlets
    
    @IBOutlet var deleteView: DeleteView!
    
    //MARK: - Override Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configurePresentation()
    }
    
    override func setupBinding() {
        super.setupBinding()
        
        viewModel
            .$title
            .sink { [weak self ] title in
                self?.deleteView.titleLabel.text = title
            }
            .store(in: &bag)
        
        viewModel
            .$actionTitle
            .sink { [weak self] actionTitle in
                self?.deleteView.actionButton.setTitle(actionTitle, for: .normal)
            }
            .store(in: &bag)
    }
    
    //MARK: - Action Methods
    
    
    @IBAction
    func actionButtonTapped(_ sender: Any) {
        viewModel.handleActionButtonTapped()
    }
    
    @IBAction
    func cancelButtonTapped(_ sender: Any) {
        viewModel.handleCancelButtonTapped()
    }
    
    //MARK: - Private Methods
    
    private func configurePresentation() {
        let presentationController = presentationController as? UISheetPresentationController
        presentationController?.detents = [.custom(resolver: { _ in
            240
        })]
    }
}
