//
//  UICollectionViewCell.swift
//  BaseCode
//
//  Created by  on 27/07/2023.
//

import UIKit

extension UICollectionViewCell {

    static var identifier: String {
        String(describing: self)
    }
    
}

