//
//  NotificationName.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 21/12/2023.
//

import Foundation

extension Notification.Name {

    static let pdfsUpdated = Notification.Name("pdfsUpdated")
}
