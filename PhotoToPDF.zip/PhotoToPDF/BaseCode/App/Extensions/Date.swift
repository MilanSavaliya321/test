//
//  Date.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 21/11/2023.
//

import Foundation

extension Date {
    
    static var dateFormat: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy"
        return formatter
    }()
}
