//
//  String.swift
//  BaseCode
//
//  Created by  on 27/07/2023.
//

import Foundation

extension String {

    static let empty = ""
    
    var isValidFileName: Bool {
        let invalidCharacters = CharacterSet(charactersIn: "/?<>\\:*|\"")
        guard let _ = rangeOfCharacter(from: invalidCharacters) else {
            return true
        }
        return false
    }
    
    func capitalizeFileName() -> String {
        let fileURL = URL(fileURLWithPath: self)
        let fileName = fileURL.deletingPathExtension().lastPathComponent
        let capitalizedFileName = fileName.capitalized
        let fileExtension = fileURL.pathExtension

        let capitalizedFileNameWithExtension = "\(capitalizedFileName).\(fileExtension)"
        return capitalizedFileNameWithExtension
    }
}
