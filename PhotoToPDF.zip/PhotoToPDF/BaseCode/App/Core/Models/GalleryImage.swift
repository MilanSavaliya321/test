//
//  GalleryImage.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 12/12/2023.
//

import UIKit

struct GalleryImage {
    
    var image: UIImage
    var imageName: String
}
