//
//  ShareViewController.swift
//  BaseCodeShareExtention
//
//  Created by Milan's Mac  on 21/03/24.
//

import UIKit
import MobileCoreServices

class ShareViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Share")
        
        guard let extensionItem = extensionContext?.inputItems.first as? NSExtensionItem,
              let itemProvider = extensionItem.attachments?.first else {
            self.extensionContext?.completeRequest(returningItems: nil, completionHandler: nil)
            return
        }
        
        print(itemProvider)
        
        let semaphore = DispatchSemaphore(value: 0)
        var fileURL: URL?
        
        itemProvider.loadItem(forTypeIdentifier: "public.url", options: nil) { item, error in
            defer {
                semaphore.signal()
            }
            
            guard let url = item as? URL else {
                self.extensionContext?.completeRequest(returningItems: nil, completionHandler: nil)
                return
            }
            
            fileURL = url
            self.openURL(url: NSURL(string:"openPdf://OpenVC?url=\(fileURL?.absoluteString ?? "")")!)
        }
    }
}

extension ShareViewController {
    func openURL(url: NSURL) {
        do {
            let application = try self.sharedApplication()
            application.open(url as URL, options: [:]) { success in
                if success {
                    self.extensionContext?.completeRequest(returningItems: nil, completionHandler: nil)
                    print("URL opened successfully")
                } else {
                    self.extensionContext?.completeRequest(returningItems: nil, completionHandler: nil)
                    print("Failed to open URL")
                }
            }
//            application.performSelector(inBackground: #selector(UIApplication.openURL(_:)), with: url)
        } catch {
            return
        }
    }
    
    func sharedApplication() throws -> UIApplication {
        var responder: UIResponder? = self
        while responder != nil {
            if let application = responder as? UIApplication {
                return application
            }
            
            responder = responder?.next
        }
        
        throw NSError(domain: "UIInputViewController+sharedApplication.swift", code: 1, userInfo: nil)
    }
}
