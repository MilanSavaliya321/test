//
//  UIFont.swift
//  BaseCode
//
//  Created by  on 27/07/2023.
//

import UIKit

extension UIFont.Weight {

    var name: String {
        switch self {
        case .regular:
            return "Regular"
        case .ultraLight:
            return "ExtraLight"
        case .thin:
            return "Thin"
        case .light:
            return "Light"
        case .medium:
            return "Medium"
        case .semibold:
            return "SemiBold"
        case .bold:
            return "Bold"
        case .black:
            return "Black"
        default:
            return ""
        }
    }
}

extension UIFont {

    static func current(withWeight weight: Weight, andSize size: CGFloat) -> UIFont {
        let fontName = "\(Config.poppins)-\(weight.name)"
        return UIFont(name: fontName, size: size)!
    }

}
