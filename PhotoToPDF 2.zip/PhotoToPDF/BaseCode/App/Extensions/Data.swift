//
//  Data.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 17/12/2023.
//

import PDFKit
import UIKit

extension Data {
    
    func generatePDFPreview() -> UIImage? {
        if let pdfDocument = PDFDocument(data: self),
           let firstPage = pdfDocument.page(at: 0) {
            
            let pageRect = firstPage.bounds(for: .mediaBox)
            UIGraphicsBeginImageContextWithOptions(pageRect.size, false, 0.0)
            let context = UIGraphicsGetCurrentContext()
            
            context?.setFillColor(UIColor.white.cgColor)
            context?.fill(pageRect)
            
            context?.translateBy(x: 0, y: pageRect.size.height)
            context?.scaleBy(x: 1.0, y: -1.0)
            
            firstPage.draw(with: .mediaBox, to: context!)
            
            let previewImage = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            
            return previewImage
        }
        
        return nil
    }
    
    

    
    
    
    
}
