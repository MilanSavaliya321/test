//
//  PdfIUtils.swift
//  BaseCode
//
//  Created by Kaynat Rana on 12/02/2024.
//

import Foundation
import Foundation
import PDFKit
import UIKit
import Compression
import Foundation
import Compression

class PdfIUtils {
    
    static func savePdfFile(data:Data, fileName:String,onSave: @escaping (URL?) -> Void, onError: @escaping () -> Void) {
        let documentsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let pdfUrl = documentsUrl.appendingPathComponent(fileName)
        do {
            try data.write(to: pdfUrl)
            onSave(pdfUrl)
        } catch {
            onError()
        }
    }
    
    
    static func savePdfFile(data:Data, fileUri:URL?, onSave: @escaping (URL?) -> Void, onError: @escaping () -> Void) {
    do {
            try data.write(to: fileUri!)
            onSave(fileUri)
        } catch {
            onError()
        }
    }
    
    
    static func extractImagesFromPDF(pdfURL: URL?) -> [UIImage] {
        guard let pdfURL = pdfURL else {
               print("PDF URL is nil")
               return []
           }
        var images: [UIImage] = []
        
        if let pdfDocument = PDFDocument(url: pdfURL) {
            for pageIndex in 0 ..< pdfDocument.pageCount {
                if let page = pdfDocument.page(at: pageIndex) {
                    // Get the thumbnail of the page
                    let thumbnail = page.thumbnail(of: CGSize(width: page.bounds(for: .mediaBox).width, height: page.bounds(for: .mediaBox).height), for: .cropBox)
                    images.append(thumbnail)
                }
            }
        }
        
        return images
    }
    
    
    static  func compressImages(images: [UIImage], compressionQuality: CGFloat) -> [Data] {
        var compressedImageData: [Data] = []
        
        for image in images {
            if let compressedData = image.jpegData(compressionQuality: compressionQuality) {
                compressedImageData.append(compressedData)
            }
        }
        
        return compressedImageData
    }
    
    static   func createPDFFromImages(compressedImageData: [Data]) -> URL? {
        let pdfURL = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("compressedPDF.pdf")
        
        UIGraphicsBeginPDFContextToFile(pdfURL.path, CGRect.zero, nil)
        defer {
            UIGraphicsEndPDFContext()
        }
        
        for imageData in compressedImageData {
            if let image = UIImage(data: imageData) {
                UIGraphicsBeginPDFPageWithInfo(CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height), nil)
                image.draw(in: CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height))
            }
        }
        
        return pdfURL
    }

    
    static   func getFileSize(url: URL?) -> Double {
        guard let url = url else {
               print("PDF URL is nil")
               return 0
           }
        do {
            let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
            if let fileSize = attributes[FileAttributeKey.size] as? Int64 {
                //return Double(fileSize) / (1024.0 * 1024.0)
                return Double(String(format: "%.2f", Double(fileSize) / (1024.0 * 1024.0))) ??  0
            }
        } catch {
            print("Error: \(error)")
        }
        
       // (\(String(format: "%.2f", Double(viewModel.pdfData.count) / (1024.0 * 1024.0)))MB)
        return 0
    }
    
    static  func getPdfPagesCount(url: URL?) -> Int {
        guard let url = url else {
               print("PDF URL is nil")
               return 0
           }
        if let pdfDocument = PDFDocument(url: url) {
            return pdfDocument.pageCount
        }
        
        return 0
    }
    
    static func compressPdf(url:URL?,compressionQuality:CGFloat) ->  Data?{
        do {
            let images = PdfIUtils.extractImagesFromPDF(pdfURL:url)
            let comressImages = PdfIUtils.compressImages(images: images, compressionQuality:compressionQuality)
            let pdfURL = PdfIUtils.createPDFFromImages(compressedImageData: comressImages)
            let newSize = PdfIUtils.getFileSize(url: pdfURL)
            return try Data(contentsOf: pdfURL!)
        } catch {
              return nil
           }
       
    }
}
