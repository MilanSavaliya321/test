//
//  Sheet.swift
//  BaseCode
//
//  Created by  on 27/07/2023.
//

import UIKit

enum Sheet {

    case filter(selectedOption: SortOption, selectedOptionClosure: ((_ option: SortOption) -> Void))
    case pdfRename(pdfName: String, selectedName: ((_ pdfName: String) -> Void))
    case setPassword(selectedPassword: ((_ password: String) -> Void))
    case enterPassword(selectedPassword: ((_ password: String) -> Void))
    case delete(title: String, actionTitle: String, actionButtonClosure: (() -> Void))
    case photosSelection(selectionClosure: ((_ selectedOption: PhotosSelectionViewModel.PhotosSelection) -> Void), isFromHome: Bool)
    case documentSelection(selectionClosure: ((_ selectedOption: MergeDocumentViewModel.DocumentSelection) -> Void))

    func controller() -> UIViewController {
        switch self {
        case let .filter(selectedOption, selectedOptionClosure):
            let viewModel = FilterViewModel(selectedOption: selectedOption, selectedOptionClosure: selectedOptionClosure)
            return FilterViewController(viewModel: viewModel)
            
        case let .pdfRename(pdfName, selectedName):
            let viewModel = PDFRenameViewModel(pdfName: pdfName, selectedName: selectedName)
            return PDFRenameViewController(viewModel: viewModel)
            
        case let .setPassword(selectedPassword):
            let viewModel = SetPasswordViewModel(selectedPassword: selectedPassword)
            return SetPasswordViewController(viewModel: viewModel)
            
        case let .enterPassword(selectedPassword):
            let viewModel = EnterPasswordViewModel(selectedPassword: selectedPassword)
            return EnterPasswordViewController(viewModel: viewModel)
            
        case let .delete(title, actionTitle, actionButtonClosure):
            let viewModel = DeleteViewModel(title: title, actionTitle: actionTitle, actionButtonClosure: actionButtonClosure)
            return DeleteViewController(viewModel: viewModel)
            
        case let .photosSelection(selectionClosure, isFromHome):
            let viewModel = PhotosSelectionViewModel(selectionClosure: selectionClosure, isFromHome: isFromHome)
            return PhotosSelectionViewController(viewModel: viewModel)
            
        case let .documentSelection(selectionClosure):
            let viewModel = MergeDocumentViewModel(selectionClosure: selectionClosure)
            return MergeDocumentViewController(viewModel: viewModel)
        }
    }
}
