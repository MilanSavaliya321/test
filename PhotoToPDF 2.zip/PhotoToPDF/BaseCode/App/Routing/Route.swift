//
//  Route.swift
//  BaseCode
//
//  Created by  on 27/07/2023.
//

import UIKit

enum Route {

    case splash
    case home
    case settings
    case photos(images: [GalleryImage])
    case pdfOptions(images: [GalleryImage], isFromMerge: Bool)
    case mergeFiles(pdfs: [PDF])
    case pdfReady(pdfData: Data)
    case pdfPreview(pdfData: Data)
    case upgradeToProVersion
    case docxsToPdf(docxUrl: String)
    case pptToPdf(pptUrl: String)
    case excelToPdf(excelUrl: String)

    func controller() -> UIViewController {
        switch self {
        case .splash:
            let viewModel = SplashViewModel()
            return SplashViewController(viewModel: viewModel)
            
        case .home:
            let viewModel = HomeViewModel()
            return HomeViewController(viewModel: viewModel)
            
        case .settings:
            let viewModel = SettingsViewModel()
            return SettingsViewController(viewModel: viewModel)
            
        case let .photos(images):
            let viewModel = PhotosViewModel(images: images)
            return PhotosViewController(viewModel: viewModel)
            
        case let .pdfOptions(images, isFromMerge):
            let viewModel = PDFOptionsViewModel(images: images, isFromMerge: isFromMerge)
            return PDFOptionsViewController(viewModel: viewModel)
            
        case let .pdfReady(pdfData):
            let viewModel = PDFReadyViewModel(pdfData: pdfData)
            return PDFReadyViewController(viewModel: viewModel)
            
        case let .pdfPreview(pdfData):
            let viewModel = PDFPreviewViewModel(pdfData: pdfData)
            return PDFPreviewViewController(viewModel: viewModel)
            
        case .upgradeToProVersion:
            let viewModel = UpgradeToProVersionViewModel()
            return UpgradeToProVersionViewController(viewModel: viewModel)
            
        case .mergeFiles(pdfs: let pdfs):
            let viewModel = MergeFilesViewModel(pdfs: pdfs)
            return MergeFilesViewController(viewModel: viewModel)
            
        case .docxsToPdf(let docxUrl):
            let viewModel = DocxViewerVm(docxURL: docxUrl)
            return DocxViewerVc(viewModel: viewModel)
        case .pptToPdf(pptUrl: let pptUrl):
            let viewModel = DocxViewerVm(docxURL: pptUrl)
            return DocxViewerVc(viewModel: viewModel)
        case .excelToPdf(excelUrl: let excelUrl):
            let viewModel = DocxViewerVm(docxURL: excelUrl)
            return DocxViewerVc(viewModel: viewModel)
        }
    }
}
