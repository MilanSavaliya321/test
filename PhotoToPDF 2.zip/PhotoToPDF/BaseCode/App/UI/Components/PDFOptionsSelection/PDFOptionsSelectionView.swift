import UIKit

class PDFOptionsSelectionView: XibView {
    
    // MARK: - Outlets
    
    @IBOutlet weak var boxView: UIView!
    @IBOutlet weak var dashedBorder: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var boxTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var boxHeightConstraint: NSLayoutConstraint!
    @IBOutlet var paddingConstraints: [NSLayoutConstraint]!
    
    // MARK: - Lifecycle Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        viewSetup()
    }
    
    //MARK: - Public Methods
    
    func setData(_ data: PDFOptionsData, height: CGFloat) {
        nameLabel.text = data.name
        boxTopConstraint.constant = height - data.boxHeight * height
        paddingConstraints.forEach {
            $0.constant = data.padding
        }
        dashedBorder.isHidden = data.padding == 0
        boxHeightConstraint.constant = height * data.boxHeight
    }
    
    //MARK: - Private Properties
    
    private func viewSetup() {
        backgroundColor = Asset.wildSandShark.color
        
        boxView.backgroundColor = Asset.whiteShark.color
        boxView.layer.cornerRadius = 2
        
        dashedBorder.backgroundColor = Asset.whiteShark.color
        
        nameLabel.font = .current(withWeight: .regular, andSize: 14)
        nameLabel.textColor = Asset.abbeyWhite.color
    }
}
