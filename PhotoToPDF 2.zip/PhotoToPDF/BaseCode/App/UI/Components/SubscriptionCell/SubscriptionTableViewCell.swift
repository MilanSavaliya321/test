//
//  SubscriptionTableViewCell.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 24/12/2023.
//

import StoreKit
import SwiftRichString
import UIKit

class SubscriptionTableViewCell: UITableViewCell {
    
    //MARK: - Outlets
    
    @IBOutlet weak var cellView: UIView!
    @IBOutlet weak var priceAndDurationLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var isPurchasedImageView: UIImageView!
    
    //MARK: - Properties
    
    private var isPurchased: Bool = false
    private var gradientLayer: CAGradientLayer?
    
    //MARK: - Override Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        initialSetup()
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        
        if !isPurchased {
            cellView.layer.borderColor = Asset.nevadaBoulder.color.cgColor
        }
    }
    
    //MARK: - Public Methods
    
    func setupProductInformation(_ product: SKProduct) {
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .currency
        numberFormatter.locale = product.priceLocale
        let productPriceString = numberFormatter.string(from: product.price) ?? .empty
        
        var durationString: String = " /"+product.localizedTitle
        if let subscriptionPeriod = product.subscriptionPeriod {
            if subscriptionPeriod.numberOfUnits == 7, subscriptionPeriod.unit == .day {
                durationString = product.localizedTitle
            } else {
                durationString = " /\(String(subscriptionPeriod.numberOfUnits)) \(mapUnitToString(subscriptionPeriod.unit))"
            }
        }
        
    
        let activeReceipts =  StorageService.activeReceipts.filter { ($0.productId ?? "0") == product.productIdentifier}
        if let lastPurchase = activeReceipts.first {
            isPurchased = true
            cellView.layer.borderColor = UIColor.clear.cgColor
            isPurchasedImageView.isHidden = false
            priceAndDurationLabel.textColor = Asset.whiteBlack.color
            descriptionLabel.textColor = Asset.whiteBlack.color
            DispatchQueue.main.async {
                self.gradientLayer = self.cellView.addGradient(
                    withColor: [Asset.dodgarBlue.color, Asset.denim.color],
                    withDirection: .horizontal
                )
            }
        } else {
            isPurchased = false
            cellView.layer.borderColor = Asset.dodgarBlue.color.cgColor
            isPurchasedImageView.isHidden = true
            priceAndDurationLabel.textColor = Asset.nevadaBoulder.color
            descriptionLabel.textColor = Asset.nevadaBoulder.color
            if let gradientLayer  {
                DispatchQueue.main.async {
                    self.cellView.removeGradient(gradientLayer: gradientLayer)
                }
            }
        }
//        if StorageService.activeReceipts.contains(where: { $0.productId == product.productIdentifier }) {
//            isPurchased = true
//            cellView.layer.borderColor = UIColor.clear.cgColor
//            isPurchasedImageView.isHidden = false
//            priceAndDurationLabel.textColor = Asset.whiteBlack.color
//            descriptionLabel.textColor = Asset.whiteBlack.color
//            DispatchQueue.main.async {
//                self.gradientLayer = self.cellView.addGradient(
//                    withColor: [Asset.dodgarBlue.color, Asset.denim.color],
//                    withDirection: .horizontal
//                )
//            }
//        } else {
//            isPurchased = false
//            cellView.layer.borderColor = Asset.nevadaBoulder.color.cgColor
//            isPurchasedImageView.isHidden = true
//            priceAndDurationLabel.textColor = Asset.nevadaBoulder.color
//            descriptionLabel.textColor = Asset.nevadaBoulder.color
//            if let gradientLayer  {
//                DispatchQueue.main.async {
//                    self.cellView.removeGradient(gradientLayer: gradientLayer)
//                }
//            }
//        }
        
        let normal = Style {
            $0.font = UIFont.current(withWeight: .regular, andSize: 14)
        }
        let price = Style {
            $0.font = UIFont.current(withWeight: .bold, andSize: 20)
        }

        let priceAndDurationGroup = StyleXML(base: normal, ["price": price])
        let priceAndDurationString = "<price>\(productPriceString)</price> \(durationString)"
        priceAndDurationLabel.attributedText = priceAndDurationString.set(style: priceAndDurationGroup)
        
        var description: String = product.localizedDescription//.empty
     
        if let lastPurchase = activeReceipts.first {
            if(lastPurchase.expiresDate != nil){
                description = "Next Payment : "+convertDateFormat(date:lastPurchase.expiresDate!,to: "dd/MM/yyyy")
            }
        }
        descriptionLabel.text = description
        
//        if let introductoryPrice = isPurchased {
//            description = "\(String(introductoryPrice.subscriptionPeriod.numberOfUnits)) \(mapUnitToString(introductoryPrice.subscriptionPeriod.unit)) Free Trial"
//        } else if product.subscriptionPeriod == nil {
//            description = "Endless Enjoyment, a Lifetime Subscription."
//        }
        descriptionLabel.text = description
    }
    
    //MARK: - Private Methods
    
    private func initialSetup() {
        cellView.backgroundColor = .clear
        cellView.layer.cornerRadius = 13
        cellView.layer.borderWidth = 1
        cellView.layer.borderColor = Asset.dodgarBlue.color.cgColor
        
        descriptionLabel.font = .current(withWeight: .regular, andSize: 10)
    }
    func convertDateFormat(date: Date, to format: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        return dateFormatter.string(from: date)
    }
    private func mapUnitToString(_ unit: SKProduct.PeriodUnit) -> String {
        switch unit {
        case .day:
            return "Day"
        case .week:
            return "Week"
        case .month:
            return "Month"
        case .year:
            return "Year"
        default:
            return .empty
        }
    }
}
