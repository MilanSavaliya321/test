//
//  PhotoCollectionViewCell.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 04/11/2023.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    
    //MARK: - Outlets
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var deleteButton: UIButton!
    
    //MARK: - Override Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        initialSetup()
    }
    
    //MARK: - Private Methods
    
    private func initialSetup() {
        imageView.layer.cornerRadius = 2
        
        deleteButton.backgroundColor = Asset.albasterShark.color
        deleteButton.layer.cornerRadius = deleteButton.frame.width / 2.0
    }
}
