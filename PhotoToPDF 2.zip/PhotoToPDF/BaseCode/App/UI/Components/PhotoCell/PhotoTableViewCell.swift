//
//  PhotoTableViewCell.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 12/12/2023.
//

import UIKit

class PhotoTableViewCell: UITableViewCell {
    
    //MARK: - Outlets
    
    @IBOutlet weak var cellView: UIView!
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var actionButton: UIButton!
    
    //MARK: - Override Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        initialSetup()
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        
        cellView.layer.borderColor = Asset.mercuryShark.color.cgColor
    }
    
    //MARK: - Private Methods
    
    private func initialSetup() {
        cellView.backgroundColor = Asset.whiteBlack.color
        cellView.layer.cornerRadius = 8
        cellView.layer.borderWidth = 1
        cellView.layer.borderColor = Asset.mercuryShark.color.cgColor
        
        photoImageView.layer.cornerRadius = 2
        
        nameLabel.font = .current(withWeight: .regular, andSize: 16)
        nameLabel.textColor = Asset.abbeyWhite.color
    }
}
