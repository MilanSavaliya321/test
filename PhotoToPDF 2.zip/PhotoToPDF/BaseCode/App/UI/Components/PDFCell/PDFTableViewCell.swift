//
//  PDFTableViewCell.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 10/12/2023.
//

import DropDown
import UIKit

class PDFTableViewCell: UITableViewCell {
    
    //MARK: - Outlets
    
    @IBOutlet weak var cellView: UIView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var lockImageView: UIImageView!
    @IBOutlet weak var actionButton: UIButton!
    @IBOutlet weak var checkboxIcon: UIImageView!
    @IBOutlet weak var pdfIconLeadingConstraint: NSLayoutConstraint!
    
    //MARK: Properties
    
    private let dropDown = DropDown()
    var cellActionTapped: ((Int) -> Void)?
    var onCellSelected: (()->Void)?
    
    //MARK: - Override Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        initialSetup()
        dropDownViewSetup()
        actionButton.addTarget(self, action: #selector(actionButtonTapped), for: .touchUpInside)
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        
        cellView.layer.borderColor = Asset.mercuryShark.color.cgColor
    }
    
    //MARK: - Action Methods
    
    @objc
    func actionButtonTapped() {
        dropDown.show()
    }
    
    @IBAction
    func selectCellTapped(_ sender: UIButton) {
        onCellSelected?()
    }
    
    //MARK: - Public Methods
    
    func showPdfData(pdf: PDF, cellActions: [String]) {
        nameLabel.text = pdf.name.capitalizeFileName()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM, yy 'at.' HH:mm"
        timeLabel.text = "\(PdfIUtils.getFileSize(url: pdf.url))MB (\(PdfIUtils.getPdfPagesCount(url: pdf.url)) Pages) "+dateFormatter.string(from: pdf.creationDate)
        dropDown.dataSource = cellActions
        lockImageView.isHidden = pdf.isUnlocked
    }
    //MARK: - Private Methods
    
    private func initialSetup() {
        cellView.backgroundColor = Asset.whiteBlack.color
        cellView.layer.cornerRadius = 8
        cellView.clipsToBounds = true
        cellView.layer.borderWidth = 1
        cellView.layer.borderColor = Asset.mercuryShark.color.cgColor
        
        nameLabel.font = .current(withWeight: .medium, andSize: 16)
        nameLabel.textColor = Asset.abbeyWhite.color
        
        timeLabel.font = .current(withWeight: .regular, andSize: 12)
        timeLabel.textColor = Asset.abbeyWhite.color.withAlphaComponent(0.5)
    }
    
    private func dropDownViewSetup() {
        DropDown.startListeningToKeyboard()

        dropDown.textColor = Asset.abbeyWhite.color
        dropDown.selectedTextColor = Asset.abbeyWhite.color
        dropDown.textFont = .current(withWeight: .regular, andSize: 14)

        dropDown.backgroundColor = Asset.whiteBlack.color
        dropDown.selectionBackgroundColor = Asset.whiteBlack.color
        dropDown.cornerRadius = 8

        dropDown.width = 213
        dropDown.cellHeight = 54

        dropDown.separatorColor = Asset.mercuryShark.color

        dropDown.anchorView = actionButton
        
        dropDown.selectionAction = { [weak self] (index, _) in
            guard let self = self else { return }
            dropDown.hide()
            cellActionTapped?(index)
        }
    }
}
