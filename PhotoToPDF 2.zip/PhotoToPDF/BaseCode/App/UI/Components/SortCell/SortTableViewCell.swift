//
//  SortTableViewCell.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 11/12/2023.
//

import UIKit

class SortTableViewCell: UITableViewCell {
    
    //MARK: - Outlets
    
    @IBOutlet weak var titleLabel: UILabel! {
        didSet {
            titleLabel.font = .current(withWeight: .regular, andSize: 16)
        }
    }
    @IBOutlet weak var isSelectedImageView: UIImageView!
}
