//
//  PDFOptionsTableViewCell.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 04/11/2023.
//

import UIKit

class PDFOptionsTableViewCell: UITableViewCell {
    
    //MARK: - Outlets
    
    @IBOutlet weak var cellView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var firstOption: PDFOptionsSelectionView!
    @IBOutlet weak var secondOption: PDFOptionsSelectionView!
    @IBOutlet weak var thirdOption: PDFOptionsSelectionView!
    
    //MARK: - Override Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        initialSetup()
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        
        cellView.layer.borderColor = Asset.mercuryShark.color.cgColor
    }

    //MARK: - Methods
    
    func setData(_ data: PDFOptions, boxHeight height: CGFloat) {
        titleLabel.text = data.title
        firstOption.setData(data.optionsData[0], height: height)
        secondOption.setData(data.optionsData[1], height: height)
        thirdOption.setData(data.optionsData[2], height: height)
    }
    
    func setSelected(_ at: Int) {
        [firstOption, secondOption, thirdOption].forEach {
            $0?.boxView.layer.borderWidth = 1
            $0?.boxView.layer.borderColor = Asset.mercuryShark.color.cgColor
        }
        switch at {
        case 0:
            firstOption.boxView.layer.borderWidth = 2
            firstOption.boxView.layer.borderColor = Asset.dodgarBlue.color.cgColor
        case 1:
            secondOption.boxView.layer.borderWidth = 2
            secondOption.boxView.layer.borderColor = Asset.dodgarBlue.color.cgColor
        case 2:
            thirdOption.boxView.layer.borderWidth = 2
            thirdOption.boxView.layer.borderColor = Asset.dodgarBlue.color.cgColor
        default:
            break
        }
    }
    
    private func initialSetup() {
        cellView.backgroundColor = Asset.wildSandShark.color
        cellView.layer.cornerRadius = 10
        cellView.layer.borderWidth = 1
        cellView.layer.borderColor = Asset.mercuryShark.color.cgColor
        
        titleLabel.font = .current(withWeight: .medium, andSize: 16)
        titleLabel.textColor = Asset.nevadaBoulder.color
    }
}
