//
//  SettingsTableViewCell.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 12/11/2023.
//

import UIKit

class SettingsTableViewCell: UITableViewCell {
    
    //MARK: - Outlets
    
    @IBOutlet weak var cellImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var lineView: UIView!
    
    //MARK: - Override Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        initialSetup()
    }
    
    //MARK: - Private Methods
    
    private func initialSetup() {
        titleLabel.font = .current(withWeight: .regular, andSize: 16)
        titleLabel.textColor = Asset.abbeyWhite.color
        
        lineView.backgroundColor = Asset.galleryBoulder.color
    }
}
