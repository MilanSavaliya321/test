//
//  CustomImageView.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 12/11/2023.
//

import UIKit

class CustomImageView: XibView {
    
    //MARK: - Outlets
    
    @IBOutlet var imageView: UIImageView!
    
    // MARK: - Lifecycle Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        viewSetup()
    }
    
    //MARK: - Public Methods
    
    func setImage(_ image: UIImage) {
        imageView.image = image
    }
    
    //MARK: - Private Methods
    
    private func viewSetup() {
        layer.cornerRadius = 6
        backgroundColor = Asset.whiteShark.color
    }
}
