//
//  PDFPreviewViewModel.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 13/11/2023.
//

import Foundation

class PDFPreviewViewModel: ViewModel {
    
    //MARK: - Properties
    
    var pdfData: Data
    
    //MARK: - Initializers
    
    init(pdfData: Data) {
        self.pdfData = pdfData
    }
    
    //MARK: - Methods
    
    func handleBackTapped() {
        router.pop()
    }
}
