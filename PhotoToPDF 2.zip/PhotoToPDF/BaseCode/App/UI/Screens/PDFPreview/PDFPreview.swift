//
//  PDFPreview.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 13/11/2023.
//

import UIKit
import WebKit

class PDFPreviewView: UIView {
    
    //MARK: - Outlets
    
    @IBOutlet weak var pdfContainerView: UIView!
    @IBOutlet weak var pdfView: WKWebView!
    @IBOutlet weak var shareButton: UIButton!
    
    //MARK: - Overriden Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        viewSetup()
    }
    
    //MARK: - Private Methods
    
    private func viewSetup() {
        pdfContainerView.layer.cornerRadius = 10
        pdfContainerView.backgroundColor = Asset.wildSandShark.color
        
        pdfView.backgroundColor = .white
        pdfView.isOpaque = false
        pdfView.layer.cornerRadius = 5
        pdfView.scrollView.showsVerticalScrollIndicator = false
        pdfView.scrollView.showsHorizontalScrollIndicator = false
        
        shareButton.layer.cornerRadius = 12
        shareButton.layer.borderWidth = 1
        shareButton.layer.borderColor = Asset.dodgarBlue.color.cgColor
        
        shareButton.setTitle("Share", for: .normal)
        shareButton.titleLabel?.font = .current(withWeight: .semibold, andSize: 16)
        shareButton.setTitleColor(Asset.dodgarBlue.color, for: .normal)
    }
}
