//
//  PDFOptionsView.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 04/11/2023.
//

import UIKit

class PDFOptionsView: UIView {
    
    //MARK: - Outlets
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var loaderView: UIView!
    @IBOutlet weak var processingDocumentLabel: UILabel!
    @IBOutlet weak var progessPercentageLabel: UILabel!
    @IBOutlet weak var progressBarView: UIProgressView!
    @IBOutlet weak var cancelButton: UIButton!
    
    //MARK: - Outlets
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        initialSetup()
    }
    
    //MARK: - Public Methods
    
    func showLoaderProgress(_ progress: Float) {
        progessPercentageLabel.text = "\(Int(progress * 100))%"
        progressBarView.progress = Float(progress)
    }
    
    //MARK: - Private Methods
    
    private func initialSetup() {
        loaderView.backgroundColor = Asset.background.color
        
        processingDocumentLabel.text = "Processing Document"
        processingDocumentLabel.font = .current(withWeight: .regular, andSize: 16)
        processingDocumentLabel.textColor = Asset.capeCodWhite.color
        
        progessPercentageLabel.font = .current(withWeight: .regular, andSize: 16)
        progessPercentageLabel.textColor = Asset.capeCodWhite.color
        
        progressBarView.layer.cornerRadius = 4
        progressBarView.trackTintColor = Asset.frenchPass.color
        progressBarView.progressTintColor = Asset.dodgarBlue.color
        
        cancelButton.layer.cornerRadius = 8
        cancelButton.layer.borderWidth = 1
        cancelButton.layer.borderColor = Asset.dodgarBlue.color.cgColor
        
        cancelButton.setTitle("Cancel", for: .normal)
        cancelButton.titleLabel?.font = .current(withWeight: .semibold, andSize: 16)
        cancelButton.setTitleColor(Asset.dodgarBlue.color, for: .normal)
    }
}
