//
//  PDFOptionsViewController.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 04/11/2023.
//

import UIKit

class PDFOptionsViewController: ViewController<PDFOptionsViewModel> {
    
    //MARK: - Outlets
    
    @IBOutlet var pdfOptionsView: PDFOptionsView!
    
    //MARK: - Properties
    
    var isFromMerge = false
    private var boxHeight: CGFloat!
    
    //MARK: - Overriden Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if viewModel.isFromMerge {
            viewModel.margin = .normal
            viewModel.orientation = .original
            viewModel.size = .original
            pdfOptionsView.loaderView.isHidden = false
            pdfOptionsView.showLoaderProgress(0)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
                self.doneButtonTapped()
            })
        } else {
            setupNavigationItems()
            tableViewSetup()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        pdfOptionsView.loaderView.isHidden = !viewModel.isFromMerge
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        
        pdfOptionsView.tableView.reloadData()
    }
    
    override func setupBinding() {
        viewModel
            .$margin
            .sink { [weak self] _ in
                self?.pdfOptionsView.tableView.reloadData()
            }
            .store(in: &bag)
        
        viewModel
            .$orientation
            .sink { [weak self] _ in
                self?.pdfOptionsView.tableView.reloadData()
            }
            .store(in: &bag)
        
        viewModel
            .$size
            .sink { [weak self] _ in
                self?.pdfOptionsView.tableView.reloadData()
            }
            .store(in: &bag)
    }
    
    //MARK: - Action Methods
    
    @objc
    func doneButtonTapped() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            navigationItem.rightBarButtonItem = nil
            navigationItem.leftBarButtonItem = nil
            
            pdfOptionsView.loaderView.isHidden = false
            pdfOptionsView.showLoaderProgress(0)
        }
        
        DispatchQueue.global().async {
            if let pdfData = self.convertImagesToPDF(
                images: self.viewModel.images.map { $0.image },
                margin: self.viewModel.margin,
                orientation: self.viewModel.orientation,
                size: self.viewModel.size
            ) {
                DispatchQueue.main.async {
                    self.pdfOptionsView.loaderView.isHidden = true
                    self.viewModel.moveToPDFPreview(pdfData)
                }
            }
        }
    }
    
    @IBAction
    func cancelButtonTapped(_ sender: Any) {
        pdfOptionsView.loaderView.isHidden = true
        setupNavigationItems()
        viewModel.handleBackTapped()
    }
    
    @objc
    func firstOptionTapped(_ sender: UITapGestureRecognizer) {
        guard let cellIndex = sender.view?.tag,
              let pdfPption = PDFOptions(rawValue: cellIndex)else {
            return
        }
        switch pdfPption {
        case .margins:
            if viewModel.margin.rawValue != 0 {
                viewModel.margin = MarginOption(rawValue: 0)!
            }
        case .orientation:
            if viewModel.orientation.rawValue != 0 {
                viewModel.orientation = ImageOrientation(rawValue: 0)!
            }
        case .size:
            if viewModel.size.rawValue != 0 {
                viewModel.size = PaperSize(rawValue: 0)!
            }
        }
    }
    
    @objc
    func secondOptionTapped(_ sender: UITapGestureRecognizer) {
        guard let cellIndex = sender.view?.tag,
              let pdfPption = PDFOptions(rawValue: cellIndex) else {
            return
        }
        switch pdfPption {
        case .margins:
            if viewModel.margin.rawValue != 1 {
                viewModel.margin = MarginOption(rawValue: 1)!
            }
        case .orientation:
            if viewModel.orientation.rawValue != 1 {
                viewModel.orientation = ImageOrientation(rawValue: 1)!
            }
        case .size:
            if viewModel.size.rawValue != 1 {
                viewModel.size = PaperSize(rawValue: 1)!
            }
        }
    }
    
    @objc
    func thirdOptionTapped(_ sender: UITapGestureRecognizer) {
        guard let cellIndex = sender.view?.tag,
              let pdfPption = PDFOptions(rawValue: cellIndex) else {
            return
        }
        switch pdfPption {
        case .margins:
            if viewModel.margin.rawValue != 2 {
                viewModel.margin = MarginOption(rawValue: 2)!
            }
        case .orientation:
            if viewModel.orientation.rawValue != 2 {
                viewModel.orientation = ImageOrientation(rawValue: 2)!
            }
        case .size:
            if viewModel.size.rawValue != 2 {
                viewModel.size = PaperSize(rawValue: 2)!
            }
        }
    }
    
    @objc
    func backButtonTapped() {
        viewModel.handleBackTapped()
    }
    
    //MARK: - Private Methods
    
    private func setupNavigationItems() {
        title = "PDF Layout"
        navigationController?.navigationBar.titleTextAttributes = [
            .foregroundColor: Asset.capeCodWhite.color,
            .font: UIFont.current(withWeight: .bold, andSize: 20)
        ]
        
        let doneButton = UIBarButtonItem(
            title: "Done",
            style: .plain,
            target: self,
            action: #selector(doneButtonTapped)
        )
        doneButton.setTitleTextAttributes(
            [
                .font: UIFont.current(withWeight: .semibold, andSize: 16),
                .foregroundColor: Asset.dodgarBlue.color
            ],
            for: .normal
        )
        navigationItem.rightBarButtonItem = doneButton
        
        let backButton = UIBarButtonItem(
            image: Asset.backArrow.image,
            style: .plain,
            target: self,
            action: #selector(backButtonTapped)
        )
        backButton.tintColor = Asset.capeCodWhite.color
        navigationItem.leftBarButtonItem = backButton
        navigationItem.hidesBackButton = true
    }
    
    private func tableViewSetup() {
        let tableWidth = UIScreen.main.bounds.width
        let boxWidth = (tableWidth - 109) / 3
        boxHeight =  boxWidth * 1.17
        pdfOptionsView.tableView.registerNib(for: PDFOptionsTableViewCell.self)
        pdfOptionsView.tableView.delegate = self
        pdfOptionsView.tableView.dataSource = self
    }

    private func convertImagesToPDF(images: [UIImage], margin: MarginOption, orientation: ImageOrientation, size: PaperSize) -> Data? {
        autoreleasepool {
            let pdfData = NSMutableData()
            let pdfPageBounds: CGRect
            switch size {
            case .letter:
                pdfPageBounds = CGRect(x: 0, y: 0, width: 612, height: 792)
            case .A4:
                pdfPageBounds = CGRect(x: 0, y: 0, width: 595, height: 842)
            case .original:
                pdfPageBounds = CGRect(x: 0, y: 0, width: 500, height: 709)
            }
            UIGraphicsBeginPDFContextToData(pdfData, pdfPageBounds, nil)

            var pdfImages: [UIImage]
            switch orientation {
            case .original:
                pdfImages = images
            case .portrait, .landscape:
                pdfImages = convertImages(images, to: orientation)
            }

            for i in 0..<pdfImages.count {
                let image = pdfImages[i]
                DispatchQueue.main.async {
                    self.pdfOptionsView.showLoaderProgress(Float(i)/Float(pdfImages.count))
                }
                autoreleasepool {
                    UIGraphicsBeginPDFPage()
                    UIColor.white.setFill()
                    UIRectFill(pdfPageBounds)

                    let marginOffset: CGFloat
                    switch margin {
                    case .normal:
                        marginOffset = 40.0
                    case .narrow:
                        marginOffset = 20.0
                    case .none:
                        marginOffset = 0.0
                    }

                    let imageSize: CGSize
                    switch size {
                    case .letter:
                        imageSize = CGSize(width: 612 - 2 * marginOffset, height: 792 - 2 * marginOffset)
                    case .A4:
                        imageSize = CGSize(width: 595 - 2 * marginOffset, height: 842 - 2 * marginOffset)
                    case .original:
                        imageSize = CGSize(width: 500 - 2 * marginOffset, height: 709 - 2 * marginOffset)
                    }

                    let imageAspectRatio = image.size.width / image.size.height
                    let pageAspectRatio = imageSize.width / imageSize.height

                    var imageRect = CGRect.zero
                    if imageAspectRatio > pageAspectRatio {
                        imageRect.size.width = imageSize.width
                        imageRect.size.height = imageSize.width / imageAspectRatio
                    } else {
                        imageRect.size.height = imageSize.height
                        imageRect.size.width = imageSize.height * imageAspectRatio
                    }

                    imageRect.origin.x = (pdfPageBounds.size.width - imageRect.size.width) / 2
                    imageRect.origin.y = (pdfPageBounds.size.height - imageRect.size.height) / 2

                    image.draw(in: imageRect)
                }
            }
            UIGraphicsEndPDFContext()

            return pdfData as Data
        }
    }
    
    private func convertImages(_ images: [UIImage], to orientation: ImageOrientation) -> [UIImage] {
        var convertedImages = [UIImage]()
        let context = CIContext()
        for image in images {
            autoreleasepool {
                if let ciImage = CIImage(image: image) {
                    if orientation == .portrait,
                       image.size.width > image.size.height {
                        let transform = CGAffineTransform(rotationAngle: 90.0 * (.pi / 180))
                        let rotatedImage = ciImage.transformed(by: transform)
                        let transformedImage = UIImage(cgImage: context.createCGImage(rotatedImage, from: rotatedImage.extent)!)
                        convertedImages.append(transformedImage)
                    } else if orientation == .landscape,
                              image.size.height > image.size.width {
                        let transform = CGAffineTransform(rotationAngle: -90.0 * (.pi / 180))
                        let rotatedImage = ciImage.transformed(by: transform)
                        let transformedImage = UIImage(cgImage: context.createCGImage(rotatedImage, from: rotatedImage.extent)!)
                        convertedImages.append(transformedImage)
                    } else {
                        convertedImages.append(image)
                    }
                }
            }
        }
        return convertedImages
    }
}

//MARK: - UITableViewDataSource Conformance

extension PDFOptionsViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        PDFOptions.allCases.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: PDFOptionsTableViewCell = tableView.dequeueCell(for: indexPath)
        cell.firstOption.tag = indexPath.row
        cell.firstOption.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(firstOptionTapped)))
        cell.secondOption.tag = indexPath.row
        cell.secondOption.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(secondOptionTapped)))
        cell.thirdOption.tag = indexPath.row
        cell.thirdOption.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(thirdOptionTapped)))
        cell.setData(PDFOptions(rawValue: indexPath.row)!, boxHeight: boxHeight)
        cell.setSelected(viewModel.selectedValueIndex(at: indexPath))
        return cell
    }
}

//MARK: - UITableViewDelegate Conformance

extension PDFOptionsViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        boxHeight + 100
    }
}
