//
//  PDFOptionsViewModel.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 04/11/2023.
//

import Foundation
import UIKit

enum PDFOptions: Int, CaseIterable {
    
    case margins
    case orientation
    case size
    
    var title: String {
        switch self {
        case .margins:
            return "Margins"
        case .orientation:
            return "Orientation"
        case .size:
            return "Size"
        }
    }
    
    var optionsData: [PDFOptionsData] {
        switch self {
        case .margins:
            return MarginOption.allCases.map { $0.data }
        case .orientation:
            return ImageOrientation.allCases.map { $0.data }
        case .size:
            return PaperSize.allCases.map { $0.data}
        }
    }
}

enum MarginOption: Int, CaseIterable {
    
    case normal
    case narrow
    case none
    
    var data: PDFOptionsData {
        switch self {
        case .normal:
            return PDFOptionsData(name: "Normal", padding: 10, boxHeight: 1)
        case .narrow:
            return PDFOptionsData(name: "Narrow", padding: 5, boxHeight: 1)
        case .none:
            return PDFOptionsData(name: "None", padding: 0, boxHeight: 1)
        }
    }
}

enum ImageOrientation: Int, CaseIterable {
    
    case original
    case portrait
    case landscape
    
    var data: PDFOptionsData {
        switch self {
        case .original:
            return PDFOptionsData(name: "Original", padding: 10, boxHeight: 1)
        case .portrait:
            return PDFOptionsData(name: "Portrait", padding: 10, boxHeight: 1)
        case .landscape:
            return PDFOptionsData(name: "Landscape", padding: 10, boxHeight: 0.75)
        }
    }
}

enum PaperSize: Int, CaseIterable {
    
    case letter
    case A4
    case original
    
    var data: PDFOptionsData {
        switch self {
        case .letter:
            return PDFOptionsData(name: "Letter", padding: 10, boxHeight: 1)
        case .A4:
            return PDFOptionsData(name: "A4", padding: 5, boxHeight: 1)
        case .original:
            return PDFOptionsData(name: "Original", padding: 0, boxHeight: 1)
        }
    }
}

class PDFOptionsViewModel: ViewModel {
    
    //MARK: - Properties
    
    @Published var margin: MarginOption = .normal
    @Published var orientation: ImageOrientation! = .original
    @Published var size: PaperSize = .letter
    var images: [GalleryImage]
    var isFromMerge = false
    
    //MARK: - Initializers
    
    init(images: [GalleryImage], isFromMerge: Bool) {
        self.images = images
        self.isFromMerge = isFromMerge
    }
    
    //MARK: - Methods
    
    func selectedValueIndex(at index: IndexPath) -> Int {
        let option = PDFOptions(rawValue: index.row)!
        switch option {
        case .margins:
            return margin.rawValue
        case .orientation:
            return orientation.rawValue
        case .size:
            return size.rawValue
        }
    }
    
    func handleBackTapped() {
        router.pop()
    }
    
    func moveToPDFPreview(_ data: Data) {
        router.append(.pdfReady(pdfData: data))
    }
}
