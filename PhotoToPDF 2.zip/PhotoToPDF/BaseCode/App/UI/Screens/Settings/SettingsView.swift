//
//  SettingsView.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 12/11/2023.
//

import UIKit

class SettingsView: UIView {
    
    //MARK: - Outlets
    
    @IBOutlet weak var upgradeToProButton: UIButton!
    @IBOutlet weak var proView: UIView!
    @IBOutlet weak var changePlanButton: UIButton!
    @IBOutlet weak var moreLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    //MARK: - Override Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        initialSetup()
        tableView.sectionHeaderTopPadding = .zero
    }
    
    //MARK: - Private Methods
    
    private func initialSetup() {
        
        proView.layer.cornerRadius = 12
        proView.layer.borderWidth = 1
        proView.layer.borderColor = Asset.lightPinkBorder.color.cgColor
        
        upgradeToProButton.layer.cornerRadius = 12
        upgradeToProButton.layer.borderWidth = 1
        upgradeToProButton.layer.borderColor = Asset.dodgarBlue.color.cgColor
        upgradeToProButton.setTitle("  Upgrade to PDF Pro", for: .normal)
        upgradeToProButton.titleLabel?.font = .current(withWeight: .semibold, andSize: 16)
        upgradeToProButton.setTitleColor(Asset.dodgarBlue.color, for: .normal)
        
        proView.layer.cornerRadius = 12
        
        changePlanButton.layer.cornerRadius = 4
        changePlanButton.layer.borderWidth = 1
        changePlanButton.layer.borderColor = Asset.dodgarBlue.color.cgColor
        changePlanButton.setTitle("Change Plan", for: .normal)
        changePlanButton.titleLabel?.font = .current(withWeight: .semibold, andSize: 14)
        changePlanButton.setTitleColor(Asset.dodgarBlue.color, for: .normal)
        
        tableView.layer.cornerRadius = 8
    }
}
