//
//  SettingsViewModel.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 12/11/2023.
//

import Foundation
import UIKit

enum SettingsCellSection2: Int, CaseIterable {
    
    case qrScanner
    
    var title: String {
        switch self {
        case .qrScanner:
            return "QR Code Reader : QR Scanner"
        }
    }
    
    var image: UIImage {
        switch self {
        case .qrScanner:
            return Asset.qrCodeScanner.image
        }
    }
}

enum SettingsCellSection1: Int, CaseIterable {
    
    case tellFriend
    case rateUs
    case privacyPolicy
    case termsOfService
    case getHelp
    
    var title: String {
        switch self {
        case .tellFriend:
            return "Tell a Friend"
        case .rateUs:
            return "Rate us"
        case .privacyPolicy:
            return "Privacy Policy"
        case .termsOfService:
            return "Terms of Service"
        case .getHelp:
            return "Get Help"
        }
    }
    
    var image: UIImage {
        switch self {
        case .tellFriend:
            return Asset.shareAppIcon.image
        case .rateUs:
            return Asset.rateIcon.image
        case .privacyPolicy:
            return Asset.privacyPolicyIcon.image
        case .termsOfService:
            return Asset.termsOfServiceIcon.image
        case .getHelp:
            return Asset.getHelpIcon.image
        }
    }
}

class SettingsViewModel: ViewModel {
    
    //MARK: - Published
    
    @Published var isProMember: Bool = false
    
    //MARK: - Methods
    
    func getSubscribedStatus() {
        isProMember = StorageService.isSubscribed
    }
    
    func handleBackTapped() {
        router.pop()
    }
    
    func handleIsSubscribedButtonTapped() {
        router.append(.upgradeToProVersion)
    }
}
