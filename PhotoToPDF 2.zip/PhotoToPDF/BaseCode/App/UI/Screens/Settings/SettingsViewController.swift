//
//  SettingsViewController.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 12/11/2023.
//

import StoreKit
import UIKit

class SettingsViewController: ViewController<SettingsViewModel> {
    
    //MARK: - Outlets
    
    @IBOutlet var settingsView: SettingsView!
    
    //MARK: - Properties
    
    let appId = "6475708527"
    
    //MARK: - Override Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupNavigationItems()
        tableViewSetup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        viewModel.getSubscribedStatus()
    }
    
    override func setupBinding() {
        super.setupBinding()
        
        viewModel
            .$isProMember
            .receive(on: DispatchQueue.main)
            .sink { [weak self] isPro in
                self?.settingsView.upgradeToProButton.isHidden = isPro
                self?.settingsView.proView.isHidden = !isPro
            }
            .store(in: &bag)
    }
    
    //MARK: - Action Methods
    
    @IBAction
    func upgradeToProButtonTapped(_ sender: Any) {
        viewModel.handleIsSubscribedButtonTapped()
    }
    
    @IBAction
    func changePlanButtonTapped(_ sender: Any) {
        viewModel.handleIsSubscribedButtonTapped()
    }
    
    @objc
    func backButtonTapped() {
        viewModel.handleBackTapped()
    }
    
    //MARK: - Private Methods
    
    private func setupNavigationItems() {
        title = "Settings"
        navigationController?.navigationBar.titleTextAttributes = [
            .foregroundColor: Asset.capeCodWhite.color,
            .font: UIFont.current(withWeight: .bold, andSize: 20)
        ]
        
        let backButton = UIBarButtonItem(
            image: Asset.backArrow.image,
            style: .plain,
            target: self,
            action: #selector(backButtonTapped)
        )
        backButton.tintColor = Asset.capeCodWhite.color
        navigationItem.leftBarButtonItem = backButton
        navigationItem.hidesBackButton = true
    }
    
    private func tableViewSetup() {
        settingsView.tableView.registerNib(for: SettingsTableViewCell.self)
        settingsView.tableView.delegate = self
        settingsView.tableView.dataSource = self
    }
    
    private func sendMail(_ address: String?) {
        guard let mailUrlString = address,
              let mailUrl = URL(string: "mailto:\(mailUrlString)") else {
                  return
              }
        UIApplication.shared.open(mailUrl, options: [:], completionHandler: nil)
    }
    
    private func openURL(_ urlString: String) {
        guard let urlString = URL(string: urlString) else {
            return
        }
        UIApplication.shared.open(urlString)
    }
    
    private func shareApp() {
        guard let appStoreLink = URL(string: "https://itunes.apple.com/app/\(appId)") else { return }
        let activityViewController = UIActivityViewController(activityItems: [appStoreLink], applicationActivities: nil)
        activityViewController.excludedActivityTypes = [UIActivity.ActivityType.airDrop]
        activityViewController.popoverPresentationController?.sourceView = view
        present(activityViewController, animated: true, completion: nil)
    }
    
    private func promptForAppRating() {
        guard let appStoreURL = URL(string: "https://itunes.apple.com/app/\(appId)?action=write-review") else { return }
        UIApplication.shared.open(appStoreURL, options: [:], completionHandler: nil)
    }
}

//MARK: - UITableViewDataSource Conformance

extension SettingsViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = Bundle.main.loadNibNamed("SettingsHeader", owner: nil)?.first as? SettingsHeaderView
        header?.titleLabel.text = section == 0 ? "More" : "Our Other Apps"
        return header
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        2
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        section == 0 ? SettingsCellSection1.allCases.count : SettingsCellSection2.allCases.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: SettingsTableViewCell = tableView.dequeueCell(for: indexPath)
        if indexPath.section == 0 {
            cell.titleLabel.text = SettingsCellSection1(rawValue: indexPath.row)?.title
            cell.cellImageView.image = SettingsCellSection1(rawValue: indexPath.row)?.image
            cell.lineView.isHidden = indexPath.row == SettingsCellSection1.allCases.count - 1
        } else if indexPath.section == 1 {
            cell.titleLabel.text = SettingsCellSection2(rawValue: indexPath.row)?.title
            cell.cellImageView.image = SettingsCellSection2(rawValue: indexPath.row)?.image
            cell.lineView.isHidden = indexPath.row == SettingsCellSection2.allCases.count - 1
        }
        
        return cell
    }
}

//MARK: - UITableViewDelegate Conformance

extension SettingsViewController: UITableViewDelegate {

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 0 {
            switch SettingsCellSection1(rawValue: indexPath.row)! {
            case .tellFriend:
                shareApp()
            case .rateUs:
                promptForAppRating()
            case .privacyPolicy:
                openURL("https://thumbmagiclabs.com/privacy-policy/")
            case .termsOfService:
                openURL("http://thumbmagiclabs.com/terms-and-conditions/")
            case .getHelp:
                sendMail("hello@thumbmagiclabs.com")
            }
        } else if indexPath.section == 1 {
            switch SettingsCellSection2(rawValue: indexPath.row)! {
            case .qrScanner:
                openURL("https://apps.apple.com/in/app/qr-code-reader-qr-scanner/id6476440474")
            }
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        60
    }
}
