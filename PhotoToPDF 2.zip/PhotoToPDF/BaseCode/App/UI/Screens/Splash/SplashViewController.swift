//
//  SplashViewController.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 10/12/2023.
//

import UIKit

class SplashViewController: ViewController<SplashViewModel> {
    
    //MARK: - Override Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewModel.getPurchaseStatus()
    }
}
