//
//  SplashViewModel.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 10/12/2023.
//

import Foundation

class SplashViewModel: ViewModel {
    
    //MARK: - Methods
    
    func getPurchaseStatus() {
        InAppPurchaseManager.shared.fetchActiveReceipts { receipts in
            StorageService.activeReceipts = receipts ?? []
            StorageService.isSubscribed = !(receipts?.isEmpty ?? true)
            DispatchQueue.main.async {
                self.router.append(.home)
            }
        }
    }
}
