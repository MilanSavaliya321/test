//
//  MergeFilesViewController.swift
//  BaseCode
//
//  Created by Soliton on 17/02/2024.
//

import MobileCoreServices
import Photos
import PhotosUI
import StoreKit
import UIKit
import VisionKit

class MergeFilesViewController: ViewController<MergeFilesViewModel> {

    //MARK: - Outlets
    
    @IBOutlet var mergeView: MergeFilesView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupNavigationItems()
        listTableViewSetup()
    }

    private func listTableViewSetup() {
        mergeView.tableView.registerNib(for: PDFTableViewCell.self)
        mergeView.tableView.dataSource = self
        mergeView.tableView.delegate = self
        mergeView.tableView.dragDelegate = self
        mergeView.tableView.dragInteractionEnabled = true
    }
    
    private func setupNavigationItems() {
        title = "Merge Files"
        navigationController?.navigationBar.titleTextAttributes = [
            .foregroundColor: Asset.capeCodWhite.color,
            .font: UIFont.current(withWeight: .bold, andSize: 20)
        ]
        
        let nextButton = UIBarButtonItem(
            title: "Next",
            style: .plain,
            target: self,
            action: #selector(nextButtonTapped)
        )
        nextButton.setTitleTextAttributes(
            [
                .font: UIFont.current(withWeight: .semibold, andSize: 16),
                .foregroundColor: Asset.dodgarBlue.color
            ],
            for: .normal
        )
        navigationItem.rightBarButtonItem = nextButton
        
        let backButton = UIBarButtonItem(
            image: Asset.backArrow.image,
            style: .plain,
            target: self,
            action: #selector(backButtonTapped)
        )
        backButton.tintColor = Asset.capeCodWhite.color
        navigationItem.leftBarButtonItem = backButton
        navigationItem.hidesBackButton = true
    }
    
    @objc
    private func deleteImageButtonTapped(_ sender: UIButton) {
        let imageIndex = sender.tag
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)

        let deleteAction = UIAlertAction(title: "Remove Photo", style: .destructive) { (action) in
            self.viewModel.selectedPdfs.remove(at: imageIndex)
            self.mergeView.tableView.reloadData()
        }
        alertController.addAction(deleteAction)

        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)

        if let popoverController = alertController.popoverPresentationController {
            popoverController.sourceView = view
            popoverController.sourceRect = view.bounds
        }

        present(alertController, animated: true, completion: nil)
    }
    
    @objc
    func backButtonTapped() {
        let alertController = UIAlertController(
            title: "You'll lose your selection",
            message: "Are you sure you want to quit?",
            preferredStyle: .alert
        )
        
        let yesAction = UIAlertAction(title: "Yes", style: .destructive) { _ in
            self.viewModel.handleBackTapped()
        }
        
        let noAction = UIAlertAction(title: "No", style: .default) { _ in }
        
        alertController.addAction(yesAction)
        alertController.addAction(noAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
    @objc
    func nextButtonTapped() {
        viewModel.handleNextButtonTapped()
    }

    @IBAction
    func addMoreButtonTapped(_ sender: UIButton) {
        viewModel.router.showSheet(.documentSelection { selectedOption in
            switch selectedOption {
            case .recent:
                let documentPicker = UIDocumentPickerViewController(documentTypes: [kUTTypePDF as String], in: .import)
                documentPicker.delegate = self
                documentPicker.allowsMultipleSelection = true
                documentPicker.directoryURL = FileManager.default.urls(for: .documentDirectory, in: .allDomainsMask).first
                self.present(documentPicker, animated: true, completion: nil)
            case .files:
                let documentPicker = UIDocumentPickerViewController(documentTypes: [kUTTypePDF as String], in: .import)
                documentPicker.delegate = self
                documentPicker.allowsMultipleSelection = true
                self.present(documentPicker, animated: true, completion: nil)
            }
        })
    }
}

//MARK: - UITableView Methods

extension MergeFilesViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.selectedPdfs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: PDFTableViewCell = tableView.dequeueCell(for: indexPath)
        let pdf = viewModel.selectedPdfs[indexPath.row]
        cell.checkboxIcon.image = UIImage(named: "threeLines")
        cell.nameLabel.text = pdf.name.capitalizeFileName()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM, yy 'at.' HH:mm"
        cell.timeLabel.text = "\(PdfIUtils.getFileSize(url: pdf.url))MB (\(PdfIUtils.getPdfPagesCount(url: pdf.url)) Pages) "+dateFormatter.string(from: pdf.creationDate)
        cell.lockImageView.isHidden = true
        cell.actionButton.tag = indexPath.row
        cell.actionButton.addTarget(
            self,
            action: #selector(deleteImageButtonTapped),
            for: .touchUpInside
        )
        return cell
    }
}

extension MergeFilesViewController: UITableViewDragDelegate {
    
    func tableView(_ tableView: UITableView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        let dragItem = UIDragItem(itemProvider: NSItemProvider())
        dragItem.localObject = viewModel.selectedPdfs[indexPath.row]
        return [ dragItem ]
    }
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let mover = viewModel.selectedPdfs.remove(at: sourceIndexPath.row)
        viewModel.selectedPdfs.insert(mover, at: destinationIndexPath.row)
    }
}

//MARK: - UIDocumentPickerDelegate Methods

extension MergeFilesViewController: UIDocumentPickerDelegate {

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        let maxImageCount: Int = StorageService.isSubscribed ? .max : 5 - viewModel.selectedPdfs.count

        var icloudImages: [PDF] = []

        for urlIndex in 0 ..< min(urls.count, maxImageCount) {
            if let imageData = try? Data(contentsOf: urls[urlIndex]),
               let imageName = urls[urlIndex].lastPathComponent.removingPercentEncoding {
                icloudImages.append(PDF(url: urls[urlIndex], data: imageData, name: imageName, creationDate: Date(), isUnlocked: true))
            }
        }

        viewModel.selectedPdfs.append(contentsOf: icloudImages)
        mergeView.tableView.reloadData()
    }
}
