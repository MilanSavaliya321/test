//
//  UpgradeToProVersionViewController.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 24/12/2023.
//

import UIKit
import StoreKit

class UpgradeToProVersionViewController: ViewController<UpgradeToProVersionViewModel> {
    
    //MARK: - Outlets
    
    @IBOutlet var upgradeView: UpgradeToProVersionView!
    
    //MARK: - Properties
    
    let cellHeight: CGFloat = 98
    var products: [SKProduct] = []
    
    //MARK: - Override Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupNavigationItems()
        tableViewSetup()
        
        DispatchQueue.main.async {
            self.showLoader(true)
            InAppPurchaseManager.shared.fetchProducts()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        upgradeView.addGradient()
    }
    
    override func setupBinding() {
        super.setupBinding()
        
        InAppPurchaseManager.shared
            .$products
            .receive(on: DispatchQueue.main)
            .sink { [weak self] products in
                guard let self = self else { return }
                showLoader(false)
                self.products = products.sorted(by: { $0.price.compare($1.price) == .orderedAscending })
                upgradeView.subscriptionTableView.reloadData()
                upgradeView.subscriptionTableViewHeight.constant = CGFloat(products.count) * cellHeight
            }
            .store(in: &bag)
    }
    
    //MARK: - Action Methods
    
    @objc
    private func backButtonTapped() {
        navigationController?.navigationBar.barStyle = .default
        viewModel.handleBackTapped()
    }
    
    //MARK: - Private Methods
    
    private func setupNavigationItems() {
        title = "Upgrade to Pro Version"
        navigationController?.navigationBar.titleTextAttributes = [
            .foregroundColor: Asset.capeCodWhite.color,
            .font: UIFont.current(withWeight: .bold, andSize: 20)
        ]
        
        let backButton = UIBarButtonItem(
            image: Asset.backArrow.image,
            style: .plain,
            target: self,
            action: #selector(backButtonTapped)
        )
        backButton.tintColor = Asset.capeCodWhite.color
        navigationItem.leftBarButtonItem = backButton
        navigationItem.hidesBackButton = true
        navigationController?.navigationBar.barStyle = .black
    }
    
    private func tableViewSetup() {
        upgradeView.subscriptionTableView.registerNib(for: SubscriptionTableViewCell.self)
        upgradeView.subscriptionTableView.dataSource = self
        upgradeView.subscriptionTableView.delegate = self
    }
}

//MARK: - UITableView Methods

extension UpgradeToProVersionViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        products.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: SubscriptionTableViewCell = tableView.dequeueCell(for: indexPath)
        let product: SKProduct = products[indexPath.row]
        cell.setupProductInformation(product)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let product: SKProduct = products[indexPath.row]
        if StorageService.activeReceipts.contains(where: { $0.productId == product.productIdentifier }) {
            showAlert(with: "You've already purchased this subciption")
            return
        }
        if let _ = product.subscriptionPeriod,
           StorageService.activeReceipts.contains(where: { $0.expiresDate == nil }) {
            showAlert(with: "You can't buy as you have lifetime subscription")
            return
        } 
        showLoader(true)
        InAppPurchaseManager.shared.purchaseProduct(product) { purchaseStatus in
            switch purchaseStatus {
            case .inProcess:
                break
            case .completed:
                DispatchQueue.main.async {
                    self.showLoader(false)
                    self.viewModel.router.pop()
                }
            case .failed:
                DispatchQueue.main.async {
                    self.showLoader(false)
                }
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        cellHeight
    }
}
