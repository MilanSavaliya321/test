//
//  HomeViewModel.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 12/11/2023.
//

import PDFKit
import UIKit

class HomeViewModel: ViewModel {
    
    //MARK: Enum
    
    enum PDFCellAction: Int {
        case rename = 0
        case compress
        case password
        case share
        case delete
        case favorite
    }
    
    //MARK: - Properties
    
    @Published var sharePDF: URL?
    @Published var isFavoriteSelected: Bool = false {
        didSet {
            filterPDFs(withText: searchedText)
        }
    }
    @Published var deleteLockedFilePopup: IndexPath?
    var isSelectedFileProtected=false;
    var refreshPDfs: (() -> Void)?
    var pdfFiles: [PDF] = []
    var selectedPdfs = [Int]()
    var isSelection = false
    private var allPDFs: [PDF] = []
    var pdfsToMergeOrCompress: [PDF] = []
    private var sortOption: SortOption = .latestFirst {
        didSet {
            filterPDFs(withText: searchedText)
        }
    }
    var searchedText: String = .empty {
        didSet {
            filterPDFs(withText: searchedText)
        }
    }
    
    //MARK: - Initializers
    
    override init() {
        super.init()
        
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(fetchAllPDFs),
            name: .pdfsUpdated,
            object: nil
        )
    }
    
    //MARK: - Methods
    
    @objc
    func fetchAllPDFs() {
        var pdfs: [PDF] = []
        let documentsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        do {
            let pdfFilesURL = try FileManager.default.contentsOfDirectory(at: documentsUrl, includingPropertiesForKeys: nil, options: .skipsHiddenFiles)
            for pdfFileURL in pdfFilesURL {
                let data = try Data(contentsOf: pdfFileURL)
                let name = pdfFileURL.lastPathComponent
                let previewImage = data.generatePDFPreview()
                let creationDate: Date = try pdfFileURL.resourceValues(forKeys: [.creationDateKey]).creationDate!
                let isUnlocked: Bool = CGPDFDocument(pdfFileURL as CFURL)?.isUnlocked ?? true
                pdfs.append(PDF(
                    url: pdfFileURL,
                    data: data,
                    previewImage: previewImage,
                    name: name,
                    creationDate: creationDate,
                    isUnlocked: isUnlocked
                ))
            }
            self.allPDFs = pdfs
            self.filterPDFs(withText: searchedText)
        } catch { }
    }
    
    func handleFilterTapped() {
        router.showSheet(.filter(selectedOption: sortOption) { [weak self] sortOption in
            self?.sortOption = sortOption
        })
    }
    
    func checkIfAnySelectedPDFisLocked() -> Bool {
        var pdfsToMerge = [PDF]()
        selectedPdfs.forEach({
            if self.allPDFs.indices.contains($0) {
                if !self.allPDFs[$0].isUnlocked {
                    pdfsToMerge.append(self.allPDFs[$0])
                }
            }
        })
        return !pdfsToMerge.isEmpty
    }
    
    func handleMergeTapped() {
        var pdfsToMerge = [PDF]()
        selectedPdfs.forEach({
            if self.pdfFiles.indices.contains($0) {
                pdfsToMerge.append(self.pdfFiles[$0])
            }
        })
        router.append(.mergeFiles(pdfs: pdfsToMerge))
    }
    
    func handleDeleteTapped(onDeleted: @escaping ()->Void) {
        
        
        router.showSheet(.delete(title: "Delete File", actionTitle: "Delete") { [weak self] in
            guard let self = self else { return }
            self.deleteFiles(onDeleted: onDeleted)
        })
    }
    

    
    func handleCompressTapped(onCompress: @escaping ([Int:Data?]) -> Void) {
        var pdfsToCompress = [PDF]()
        selectedPdfs.forEach({
            if self.pdfFiles.indices.contains($0) {
                pdfsToCompress.append(self.pdfFiles[$0])
            }
        })
        var dataIndexDict = [Int:Data?]()
        pdfsToCompress.forEach({ pdf in
            if case pdf.isUnlocked = true {
                ///let data = try Data(contentsOf: pdf.url)
               let data = PdfIUtils.compressPdf(url:  pdf.url, compressionQuality: 80)
                if let index = allPDFs.firstIndex(where: { $0.url == pdf.url }) {
                    dataIndexDict[index] = data
                }
            }
        })
        onCompress(dataIndexDict)
    }
    
    func compressDocuments(onCompress: @escaping () -> Void) {
        pdfsToMergeOrCompress.forEach({ pdf in
            if case pdf.isUnlocked = true {
                let data = PdfIUtils.compressPdf(url:  pdf.url, compressionQuality: 80)!
                let documentsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
                let pdfUrl = documentsUrl.appendingPathComponent("\(pdf.fileNameWithoutExtension).pdf")
                do {
                    try data.write(to: pdfUrl)
                    isLoading = false
                   // alert = "PDF saved successfully"
                   // StorageService.savedPDFs += 1
                } catch {
                    isLoading = false
                    self.error = error
                }
            }
        })
        onCompress()
    }
    
    func convertDoxToPDf(docxURL: String) {
        router.append(.docxsToPdf(docxUrl: docxURL))
    }
    
    func convertPPTToPDf(docxURL: String) {
        router.append(.docxsToPdf(docxUrl: docxURL))
    }
    
    func convertExcelToPDf(docxURL: String) {
        router.append(.docxsToPdf(docxUrl: docxURL))
    }
    
    func mergeDocuments() {
        router.append(.mergeFiles(pdfs: pdfsToMergeOrCompress))
    }
    
    func handleShareTapped(completion: ([URL])->Void) {
        let filteredPDFArray = pdfFiles.enumerated().filter { selectedPdfs.contains($0.offset) }.map { $0.element }
        let urls = filteredPDFArray.map({
            $0.url
        })
        completion(urls)
    }
    
    func handleSettingsTapped() {
        router.append(.settings)
    }
    
    func compressPdfFile(at url: URL?) ->  Data?{
        return PdfIUtils.compressPdf(url:  url, compressionQuality: 80)
    }
    
    
    func imagesReceived(_ images: [GalleryImage]) {
        guard !images.isEmpty else {
            return
        }
        router.append(.photos(images: images))
    }
    
    func cellActionDataSource(at indexPath: IndexPath) -> [String] {
        return [
            "Rename",
            "Compress",
            pdfFiles[indexPath.row].isUnlocked ? "Lock File" : "Unlock File",
            "Share",
            "Delete",
            StorageService.favoritePDFs.contains(pdfFiles[indexPath.row].url) ? "Unfavorite" : "Favorite"
        ]
    }
    
    func handleIsProButtonTapped() {
        guard !StorageService.isSubscribed else { return }
        router.append(.upgradeToProVersion)
    }
    
    func handleFavoriteButtonTapped() {
        isFavoriteSelected.toggle()
    }
    
    func handlePDFCellTapped(at index: Int?) {
        guard let index = index else { return }
//        guard pdfFiles[index].isUnlocked else {
//            router.showSheet(.enterPassword() { [weak self] password in
//                guard let self = self else { return }
//                //TODO: Open Lock PDF
//            })
//            return
//        }
        router.append(.pdfPreview(pdfData: pdfFiles[index].data))
    }
    
    func cellActionButtonTapped(cellIndexPath: IndexPath, actionIndex: Int,onCompress: @escaping (Data?) -> Void) {
        guard let actionTapped = PDFCellAction(rawValue: actionIndex) else {
            return
        }
        switch actionTapped {
        case .rename:
            guard StorageService.isSubscribed else {
                router.append(.upgradeToProVersion)
                return
            }
            let pdf: PDF = pdfFiles[cellIndexPath.row]
            var pdfName = pdf.name
            if pdfName.hasSuffix(".pdf") {
                pdfName = String(pdfName.dropLast(4))
            }
            router.showSheet(.pdfRename(pdfName: pdfName) { [weak self] newName in
                guard let self = self else { return }
                let documentsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
                do {
                    let pdfFileURL = pdf.url
                    let newPDFName = "\(newName).pdf"
                    let newPDFFileURL = documentsUrl.appendingPathComponent(newPDFName)
                    pdfFiles[cellIndexPath.row].url = newPDFFileURL
                    pdfFiles[cellIndexPath.row].name = newPDFName
                    
                    refreshPDfs?()
                    
                    try FileManager.default.moveItem(at: pdfFileURL, to: newPDFFileURL)
                    
                    if let index = allPDFs.firstIndex(of: pdf) {
                        allPDFs[index].url = newPDFFileURL
                        allPDFs[index].name = newPDFName
                    }
                    
                    if let pdfURLIndex = StorageService.favoritePDFs.firstIndex(of: pdf.url) {
                        StorageService.favoritePDFs[pdfURLIndex] = newPDFFileURL
                    }
                } catch { }
            })
        case .password:
            guard pdfFiles[cellIndexPath.row].isUnlocked else {
                router.showSheet(.enterPassword { [weak self] password in
                    guard let self = self else { return }
                    guard let pdfDocument = PDFDocument(url: pdfFiles[cellIndexPath.row].url),
                          pdfDocument.isEncrypted,
                          pdfDocument.unlock(withPassword: password) else {
                        alert = "Wrong Password"
                        return
                    }
                    let options = [PDFDocumentWriteOption.userPasswordOption: "",
                                   PDFDocumentWriteOption.ownerPasswordOption: ""]
                    pdfDocument.write(to: pdfFiles[cellIndexPath.row].url, withOptions: options)
                    fetchAllPDFs()
                })
                return
            }
            guard StorageService.isSubscribed || StorageService.lockedPDFs < 1 else {
                router.append(.upgradeToProVersion)
                return
            }
            router.showSheet(.setPassword { [weak self] password in
                guard let self = self else { return }
                if let pdfDocument = PDFDocument(url: pdfFiles[cellIndexPath.row].url) {
                    let options = [PDFDocumentWriteOption.userPasswordOption: password,
                                   PDFDocumentWriteOption.ownerPasswordOption: password]
                    pdfDocument.write(to: pdfFiles[cellIndexPath.row].url, withOptions: options)
                    StorageService.lockedPDFs += 1
                    fetchAllPDFs()
                }
            })
        case .share:
            sharePDF = pdfFiles[cellIndexPath.row].url
        case .delete:
            if(!pdfFiles[cellIndexPath.row].isUnlocked){
                isSelectedFileProtected = true;
            }
           deleteLockedFilePopup = cellIndexPath
//            router.showSheet(.delete(title: "Delete File", actionTitle: "Delete") { [weak self] in
//                guard let self = self else { return }
//            
//                guard pdfFiles[cellIndexPath.row].isUnlocked else {
//                    isSelectedFileProtected = true;
//                    return
//                }
//                deleteLockedFilePopup = cellIndexPath
//                //deleteFile(at: cellIndexPath)
//            })
        case .favorite:
            guard let pdfURLIndex = StorageService.favoritePDFs.firstIndex(of: pdfFiles[cellIndexPath.row].url) else {
                StorageService.favoritePDFs.append(pdfFiles[cellIndexPath.row].url)
                if isFavoriteSelected {
                    pdfFiles = pdfFiles.filter {
                        StorageService.favoritePDFs.contains($0.url)
                    }
                }
                refreshPDfs?()
                return
            }
            StorageService.favoritePDFs.remove(at: pdfURLIndex)
            if isFavoriteSelected {
                pdfFiles = pdfFiles.filter {
                    StorageService.favoritePDFs.contains($0.url)
                }
            }
            refreshPDfs?()
        case .compress:
                let pdf: PDF = pdfFiles[cellIndexPath.row]
                if case pdf.isUnlocked = true {
                    ///let data = try Data(contentsOf: pdf.url)
                   let data = PdfIUtils.compressPdf(url:  pdf.url, compressionQuality: 80)
                    onCompress(data)
                }else{
                
                }
        }
    }
    
    func pdfOveride(data: Data,index:Int) {
        let pdfFile = pdfFiles[index]
        PdfIUtils.savePdfFile(data: data, fileUri: pdfFile.url, onSave: { url in
            self.fetchAllPDFs()
            self.refreshPDfs?()
            print("FileOveride")
        }, onError: {
                print("Error: Unable to save PDF file")
            })
        
    }

    
        func saveCompressedFile(data:Data,index:Int) {
            let pdfFile = pdfFiles[index]
            let documentsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            let pdfUrl = documentsUrl.appendingPathComponent("\(pdfFile.fileNameWithoutExtension)-copy(\(StorageService.savedPDFs)).pdf")
            PdfIUtils.savePdfFile(data: data, fileUri: pdfUrl, onSave:{_ in
                StorageService.savedPDFs += 1
                self.fetchAllPDFs()
                self.refreshPDfs?()
                print("Compress File Saved")
            }, onError: {
            })
        }
    
    func saveCompressedFiles(data:[Int: Data?], isOverride: Bool = false) {
        var pdfsWithData = [Int: (Data?, PDF)]()
        data.forEach({
            if self.pdfFiles.indices.contains($0.key) {
                pdfsWithData[$0.key] = ($0.value, self.pdfFiles[$0.key])
            }
        })
        
        pdfsWithData.forEach({ pdfWithData in
            var pdfUrl: URL? = pdfWithData.value.1.url
            if !isOverride {
                let documentsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
                pdfUrl = documentsUrl.appendingPathComponent("\(pdfWithData.value.1.fileNameWithoutExtension)-copy(\(StorageService.savedPDFs)).pdf")
            }
            PdfIUtils.savePdfFile(data: pdfWithData.value.0!, fileUri: pdfUrl, onSave:{_ in
                StorageService.savedPDFs += 1
                self.fetchAllPDFs()
                self.refreshPDfs?()
                print("Compress File Saved")
            }, onError: {
            })
        })
    }
    

    func deleteFile(at indexPath: IndexPath) {
        do {
            let pdfFileURL = pdfFiles[indexPath.row].url
            
            if let index = allPDFs.firstIndex(of: pdfFiles[indexPath.row]) {
                allPDFs.remove(at: index)
            }
            
            pdfFiles.remove(at: indexPath.row)
            refreshPDfs?()
            
            if FileManager.default.fileExists(atPath: pdfFileURL.path) {
                try FileManager.default.removeItem(at: pdfFileURL)
            }
            
            if let deleteFileURL = StorageService.favoritePDFs.firstIndex(of: pdfFileURL) {
                StorageService.favoritePDFs.remove(at: deleteFileURL)
            }
        } catch { }
    }
    

    func deleteFiles(onDeleted: @escaping ()->Void) {
        do {
            let filteredPDFArray = pdfFiles.enumerated().filter { selectedPdfs.contains($0.offset) }.map { $0.element }
            for pdf in filteredPDFArray {
                let pdfFileURL = pdf.url
                
                allPDFs.removeAll(where: {
                    $0.url == pdfFileURL
                })
                pdfFiles.removeAll(where: {
                    $0.url == pdfFileURL
                })
                if FileManager.default.fileExists(atPath: pdfFileURL.path) {
                    try FileManager.default.removeItem(at: pdfFileURL)
                }
                
                if let deleteFileURL = StorageService.favoritePDFs.firstIndex(of: pdfFileURL) {
                    StorageService.favoritePDFs.remove(at: deleteFileURL)
                }
            }
            refreshPDfs?()
            onDeleted()
        } catch { }
    }
    
    private func filterPDFs(withText text: String) {
        pdfFiles.removeAll()
        
        switch sortOption {
        case .latestFirst:
            pdfFiles = allPDFs.sorted {
                $0.creationDate > $1.creationDate
            }
        case .fileSize:
            pdfFiles = allPDFs.sorted {
                $0.data.count < $1.data.count
            }
        case .name:
            pdfFiles = allPDFs.sorted {
                $0.name < $1.name
            }
        case .oldestFirst:
            pdfFiles = allPDFs.sorted {
                $0.creationDate < $1.creationDate
            }
        }
        
        if !text.isEmpty  {
            pdfFiles = pdfFiles.filter {
                $0.name.lowercased().contains(text.lowercased())
            }
        }
        if isFavoriteSelected {
            pdfFiles = pdfFiles.filter {
                StorageService.favoritePDFs.contains($0.url)
            }
        }
        refreshPDfs?()
    }
}
