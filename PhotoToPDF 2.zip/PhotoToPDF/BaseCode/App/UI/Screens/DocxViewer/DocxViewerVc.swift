//
//  DocxViewerVc.swift
//  BaseCode
//
//  Created by AKASH BOGHANI on 11/03/24.
//

import UIKit
import WebKit

final class DocxViewerVc: ViewController<DocxViewerVm> {
    //MARK: - @IBOutlets
    @IBOutlet weak var webView: WKWebView!
    
    //MARK: - Properties
    
    //MARK: - Life-Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupNavigationItems()
        if let url = URL(string: viewModel.docxURL) {
            let request = URLRequest(url: url)
            webView.load(request)
        }
    }
    
    //MARK: - Functions
    func createPDF() -> Data? {
        let printPageRenderer = UIPrintPageRenderer()
        printPageRenderer.addPrintFormatter(webView.viewPrintFormatter(), startingAtPageAt: 0)
          
        let pageSize = CGSize(width: 500, height: 709)
        let pageRect = CGRect(x: 0, y: 30, width: pageSize.width, height: pageSize.height)
        let dataRect = CGRect(x: 0, y: 0, width: pageSize.width, height: pageSize.height - 60)
        
        printPageRenderer.setValue(NSValue(cgRect: pageRect), forKey: "paperRect")
        printPageRenderer.setValue(NSValue(cgRect: dataRect), forKey: "printableRect")
        
        let pdfData = NSMutableData()
        UIGraphicsBeginPDFContextToData(pdfData, pageRect, nil)
        for i in 0..<printPageRenderer.numberOfPages {
            UIGraphicsBeginPDFPage()
            let bounds = UIGraphicsGetPDFContextBounds()
            printPageRenderer.drawPage(at: i, in: bounds)
        }
        UIGraphicsEndPDFContext()
        
        return pdfData as Data
    }
    
    private func setupNavigationItems() {
        title = "Docx"
        navigationController?.navigationBar.titleTextAttributes = [
            .foregroundColor: Asset.capeCodWhite.color,
            .font: UIFont.current(withWeight: .bold, andSize: 20)
        ]
        
        let doneButton = UIBarButtonItem(
            title: "Create PDF",
            style: .plain,
            target: self,
            action: #selector(doneButtonTapped)
        )
        doneButton.setTitleTextAttributes(
            [
                .font: UIFont.current(withWeight: .semibold, andSize: 16),
                .foregroundColor: Asset.dodgarBlue.color
            ],
            for: .normal
        )
        navigationItem.rightBarButtonItem = doneButton
        
        let backButton = UIBarButtonItem(
            image: Asset.backArrow.image,
            style: .plain,
            target: self,
            action: #selector(backButtonTapped)
        )
        backButton.tintColor = Asset.capeCodWhite.color
        navigationItem.leftBarButtonItem = backButton
        navigationItem.hidesBackButton = true
    }
    
    @objc
    func doneButtonTapped() {
        guard let data = createPDF() else { return }
        viewModel.handleCreatePDF(pdfData: data)
    }
    
    @objc
    func backButtonTapped() {
        viewModel.handleBackTapped()
    }
}
