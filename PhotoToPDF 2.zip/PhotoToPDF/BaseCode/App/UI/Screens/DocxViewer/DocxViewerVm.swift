//
//  DocxViewerVm.swift
//  BaseCode
//
//  Created by AKASH BOGHANI on 11/03/24.
//

import Foundation

final class DocxViewerVm: ViewModel {
    //MARK: - Properties
    var docxURL: String
    
    //MARK: - Life-Cycle
    init(docxURL: String) {
        self.docxURL = docxURL
    }
    
    //MARK: - Functions
    func handleBackTapped() {
        router.pop()
    }
    
    func handleCreatePDF(pdfData: Data) {
        router.append(.pdfReady(pdfData: pdfData))
    }
}
