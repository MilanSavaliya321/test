
////////////////////////////////////
//
//  PDFReadyViewModel.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 18/12/2023.
//

import Foundation
import PDFKit
import UIKit
import Compression
import Foundation
import Compression

class PDFReadyViewModel: ViewModel {
    
    
    //MARK: - Properties
    
    @Published var fileName: String = Date.dateFormat.string(from: Date())
    @Published var protectFileTitle: String?
    private var password: String? = nil {
        didSet {
            protectFileTitle = password == nil ? "Lock File" : "UnLock File"
        }
    }
    var savedPDFUrl: URL?
    
    var pdfData: Data
    
    //MARK: - Initializers
    
    init(pdfData: Data) {
        self.pdfData = pdfData
    }
    
    //MARK: - Methods
    
    func fetchPdfData() {
        password = nil
        let currentPDF = StorageService.savedPDFs + 1
        guard currentPDF > 9 else {
            fileName = Date.dateFormat.string(from: Date()) + "-0\(currentPDF)"
            return
        }
        fileName = Date.dateFormat.string(from: Date()) + "-\(currentPDF)"
    }
    
    func handleBackTapped() {
        if savedPDFUrl != nil {
            NotificationCenter.default.post(name: .pdfsUpdated, object: nil)
        }
        router.popTo(.home)
    }
    
    func handleOpenFileViewTapped() {
        guard password == nil else {
            router.showSheet(.enterPassword() { [weak self] enterPassword in
                guard let self = self else { return }
                guard password == enterPassword else {
                    alert = "Wrong Password"
                    return
                }
                router.append(.pdfPreview(pdfData: pdfData))
            })
            return
        }
        router.append(.pdfPreview(pdfData: pdfData))
    }
    
    func handleSaveFileViewTapped() {
        if savedPDFUrl == nil {
            StorageService.savedPDFs += 1
        }
        isLoading = true
        let documentsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let pdfUrl = documentsUrl.appendingPathComponent("\(fileName).pdf")
        do {
            try pdfData.write(to: pdfUrl)
            savedPDFUrl = pdfUrl
            isLoading = false
           // alert = "PDF saved successfully"
           // StorageService.savedPDFs += 1
        } catch {
            isLoading = false
            self.error = error
        }
    }
    
    func handleProtectFileViewTapped() {
        guard let password = password else {
            guard StorageService.isSubscribed || StorageService.lockedPDFs < 1 else {
                router.append(.upgradeToProVersion)
                return
            }
            router.showSheet(.setPassword() { [weak self] enterPassword in
                guard let self = self else { return }
                password = enterPassword
                StorageService.lockedPDFs += 1
                if let savedPDFUrl = savedPDFUrl {
                    if let pdfDocument = PDFDocument(url: savedPDFUrl) {
                        let options = [PDFDocumentWriteOption.userPasswordOption: enterPassword,
                                       PDFDocumentWriteOption.ownerPasswordOption: enterPassword]
                        pdfDocument.write(to: savedPDFUrl, withOptions: options)
                    }
                }
            })
            return
        }
        router.showSheet(.enterPassword() { [weak self] enterPassword in
            guard let self = self else { return }
            guard password == enterPassword else {
                alert = "Wrong Password"
                return
            }
            self.password = nil
            if let savedPDFUrl = savedPDFUrl {
                if let pdfDocument = PDFDocument(url: savedPDFUrl) {
                    let options = [PDFDocumentWriteOption.userPasswordOption: "",
                                   PDFDocumentWriteOption.ownerPasswordOption: ""]
                    pdfDocument.write(to: savedPDFUrl, withOptions: options)
                }
            }
        })
    }
    
    func handleRenameFileViewTapped() {
        guard StorageService.isSubscribed else {
            router.append(.upgradeToProVersion)
            return
        }
        router.showSheet(.pdfRename(pdfName: fileName) { [weak self] newName in
            guard let self = self else { return }
            self.fileName = newName
            if let savedPDFUrl = savedPDFUrl {
                let documentsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
                do {
                    let newPDFName = "\(newName).pdf"
                    let newPDFFileURL = documentsUrl.appendingPathComponent(newPDFName)
                    try FileManager.default.moveItem(at: savedPDFUrl, to: newPDFFileURL)
                    self.savedPDFUrl = newPDFFileURL
                } catch { }
            }
        })
    }
    
    func handleHomeViewTapped(saveFile: Bool = false) {
        if saveFile,
           savedPDFUrl == nil {
            let documentsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            let pdfUrl = documentsUrl.appendingPathComponent("\(fileName).pdf")
            do {
                try pdfData.write(to: pdfUrl)
                savedPDFUrl = pdfUrl
                StorageService.savedPDFs += 1
            } catch { }
        }
        if savedPDFUrl != nil {
            NotificationCenter.default.post(name: .pdfsUpdated, object: nil)
        }
        router.popTo(.home)
    }
    
  
    func unlockfile(result: @escaping (Bool) -> Void) {
        guard password == nil else {
            router.showSheet(.enterPassword() { [weak self] enterPassword in
                guard let self = self else { return }
                guard password == enterPassword else {
                    alert = "Wrong Password"
                    result(false)
                return
                }
                result(true)
            })
            return
        }
        result( true)
    }
    

    
    func pdfOveride(data: Data) {
             PdfIUtils.savePdfFile(data: data, fileUri: savedPDFUrl, onSave: { url in
                guard let url = url else {
                    // Handle the case when the URL is nil
                    return
                }
                do {
                    self.pdfData = try Data(contentsOf: url)
                    StorageService.savedPDFs += 1
                    self.fileName = self.fileName // This seems unnecessary, consider removing it
                } catch {
                    // Handle the error if unable to read data from the URL
                    print("Error: \(error.localizedDescription)")
                }
            }, onError: {
                // Handle error if savePdfFile encounters an error
                print("Error: Unable to save PDF file")
            })
        
    }

        func saveCompressedFile(data:Data) {
            let documentsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            let pdfUrl = documentsUrl.appendingPathComponent("\(fileName)-copy.pdf")
            PdfIUtils.savePdfFile(data: data, fileUri: pdfUrl, onSave:{_ in
                StorageService.savedPDFs += 1
            }, onError: {
            })
        }
    
    func handleMergeTapped() {
        if let url = savedPDFUrl {
            let tempName = fileName.hasSuffix(".pdf") ? fileName : "\(fileName).pdf"
            let pdf = PDF(url: url, data: pdfData, name: tempName, creationDate: Date(), isUnlocked: password == nil)
            router.append(.mergeFiles(pdfs: [pdf]))
        }
    }
    
    func compressPdfFile1() ->  Data?{
        return PdfIUtils.compressPdf(url:  self.savedPDFUrl, compressionQuality: 80)
    }

    func compressFileViewTapped(completion: @escaping (Data?) -> Void, onError:@escaping () -> Void) {
        unlockfile { result in
            // Assuming `unlockfile` is an asynchronous operation
            if result {
                let compressedData = self.compressPdfFile1()
                completion(compressedData)
            } else {
                completion(nil)
            }
        }
    }
 
}
