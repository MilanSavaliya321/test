

//
//  PDFReadyViewController.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 18/12/2023.
//

import UIKit

class PDFReadyViewController: ViewController<PDFReadyViewModel> {

    //MARK: - Outlets
    
    @IBOutlet var pdfReadyView: PDFReadyView!
    
    //MARK: - Override Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupNavigationItems()
        viewModel.fetchPdfData()
        viewModel.handleSaveFileViewTapped()
    }
    
    override func setupBinding() {
        super.setupBinding()
        
        viewModel
            .$fileName
            .sink { [weak self] name in
                guard let self = self else { return }
                pdfReadyView.nameLabel.text = name.capitalized + ".pdf (\(String(format: "%.2f", Double(viewModel.pdfData.count) / (1024.0 * 1024.0)))MB)"
            }
            .store(in: &bag)
        
        viewModel
            .$protectFileTitle
            .sink { [weak self] protectTitle in
                guard let self = self else { return }
                pdfReadyView.protectFileTitleLabel.text = protectTitle
            }
            .store(in: &bag)
    }
    
    //MARK: - Action Methods
    
    @IBAction
    func openFileViewTapped(_ sender: Any) {
        viewModel.handleOpenFileViewTapped()
    }
    
    @IBAction
    func saveFileViewTapped(_ sender: Any) {
        viewModel.handleSaveFileViewTapped()
    }
    @IBAction
    func compressFileViewTapped(_ sender: Any) {
        viewModel.compressFileViewTapped { compressedData in
            if let compressedData = compressedData {
                self.confirmCompressOptions(data: compressedData)
            } else {
                // Handle failure or nil data
            }
        } onError: {
            
        }
    }
    
    func confirmCompressOptions(data:Data){
            let alertController = UIAlertController(
                title: "Successfully compressed PDF",
                message: "You have successfully compressed the PDF file. Please choose to create a new copy or override the original file.",
                preferredStyle: .alert
            )
    
            let yesAction = UIAlertAction(title: "Create Copy", style: .default) { _ in
                self.viewModel.saveCompressedFile(data: data)
            }
    
        let noAction = UIAlertAction(title: "Override Original", style: .default) { _ in
            self.viewModel.pdfOveride(data: data)
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .destructive) { _ in
            alertController.dismiss(animated: false)
        }
            alertController.addAction(yesAction)
            alertController.addAction(noAction)
            alertController.addAction(cancelAction)
    
            self.present(alertController, animated: true, completion: nil)
        }
    
    @IBAction
    func mergeFileViewTapped(_ sender: Any) {
        viewModel.handleMergeTapped()
    }
    
    @IBAction
    func shareFileViewTapped(_ sender: Any) {
        let activityViewController = UIActivityViewController(
            activityItems: [viewModel.pdfData],
            applicationActivities: nil
        )
        activityViewController.popoverPresentationController?.sourceView = view
        present(activityViewController, animated: true, completion: nil)
    }
    
    @IBAction
    func protectFileViewTapped(_ sender: Any) {
        viewModel.handleProtectFileViewTapped()
    }
    
    @IBAction
    func renameFileViewTapped(_ sender: Any) {
        viewModel.handleRenameFileViewTapped()
    }
    
    @IBAction
    func goToHomeViewTapped(_ sender: Any) {
        guard viewModel.savedPDFUrl != nil else {
            showSaveConfirmationPopup()
            return
        }
        viewModel.handleHomeViewTapped()
    }
    
    @objc
    func backButtonTapped() {
        viewModel.handleBackTapped()
    }
    
    //MARK: - Private Methods
    
    private func setupNavigationItems() {
        let backButton = UIBarButtonItem(
            image: Asset.backArrow.image,
            style: .plain,
            target: self,
            action: #selector(backButtonTapped)
        )
        backButton.tintColor = Asset.capeCodWhite.color
        navigationItem.leftBarButtonItem = backButton
        navigationItem.hidesBackButton = true
    }
    
    func showSaveConfirmationPopup() {
        let alertController = UIAlertController(
            title: "File not saved",
            message: "Do you want to save this file?",
            preferredStyle: .alert
        )
        
        let saveAction = UIAlertAction(title: "Save", style: .default) { _ in
            self.viewModel.handleHomeViewTapped(saveFile: true)
        }
        
        let noAction = UIAlertAction(title: "No", style: .destructive) { _ in
            self.viewModel.handleHomeViewTapped()
        }
        
        alertController.addAction(saveAction)
        alertController.addAction(noAction)
        
        present(alertController, animated: true, completion: nil)
    }
}
