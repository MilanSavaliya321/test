//
//  PhotosView.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 04/11/2023.
//

import UIKit

class PhotosView: UIView {
    
    //MARK: - Enum
    
    enum SelectionTab {
        
        case grid
        case list
        
        var title: String {
            switch self {
            case .grid:
                return "Grid"
            case .list:
                return "List"
            }
        }
    }
    
    //MARK: - Outlets
    
    @IBOutlet weak var selectionView: UIStackView!
    @IBOutlet weak var gridButton: UIButton!
    @IBOutlet weak var listButton: UIButton!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var gridCollectionView: UICollectionView!
    @IBOutlet weak var listTableView: UITableView!
    @IBOutlet weak var noPhotosLabel: UILabel!
    @IBOutlet weak var addMoreButton: UIButton!
    
    //MARK: - Overriden Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        viewSetup()
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        
        selectionView.layer.borderColor = Asset.galleryBoulder.color.cgColor
    }
    
    //MARK: - Methods
    
    func setSelectionTab(_ tab: SelectionTab) {
        setupSelectionTabs()
        switch tab {
        case .grid:
            gridButton.backgroundColor = Asset.dodgarBlue.color
            gridButton.setTitleColor(.white, for: .normal)
        case .list:
            listButton.backgroundColor = Asset.dodgarBlue.color
            listButton.setTitleColor(.white, for: .normal)
        }
    }
    
    //MARK: - Private Methods
    
    private func viewSetup() {
        selectionView.layer.cornerRadius = 8
        selectionView.backgroundColor = Asset.galleryBoulder.color.withAlphaComponent(0.8)
        selectionView.layer.borderWidth = 1
        selectionView.layer.borderColor = Asset.galleryBoulder.color.cgColor
        
        gridButton.setTitle(SelectionTab.grid.title, for: .normal)
        gridButton.titleLabel?.font = .current(withWeight: .regular, andSize: 14)
        gridButton.layer.cornerRadius = 7
        
        listButton.setTitle(SelectionTab.list.title, for: .normal)
        listButton.titleLabel?.font = .current(withWeight: .regular, andSize: 14)
        listButton.layer.cornerRadius = 7
        
        addMoreButton.layer.cornerRadius = 12
        addMoreButton.layer.borderWidth = 1
        addMoreButton.layer.borderColor = Asset.dodgarBlue.color.cgColor
        
        addMoreButton.setTitle("Add More", for: .normal)
        addMoreButton.titleLabel?.font = .current(withWeight: .semibold, andSize: 16)
        addMoreButton.setTitleColor(Asset.dodgarBlue.color, for: .normal)
    }
    
    private func setupSelectionTabs() {
        [gridButton, listButton].forEach {
            $0?.backgroundColor = .clear
            $0?.setTitleColor(Asset.capeCodWhite.color, for: .normal)
        }
    }
}
