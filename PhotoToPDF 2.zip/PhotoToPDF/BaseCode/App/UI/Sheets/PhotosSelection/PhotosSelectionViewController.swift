//
//  PhotosSelectionViewController.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 16/01/2024.
//

import UIKit

class PhotosSelectionViewController: ViewController<PhotosSelectionViewModel> {
    
    @IBOutlet var photosView: PhotosSelectionView!
    
    //MARK: - Override Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if !viewModel.isFromHome {
            photosView.compressView.isHidden = true
            photosView.mergeView.isHidden = true
        }
        configurePresentation()
    }
    
    //MARK: - Action Methods
    
    @IBAction
    func cancelButtonTapped(_ sender: Any) {
        viewModel.handleCancelButtonTapped()
    }
    
    @IBAction
    func scanViewTapped(_ sender: Any) {
        viewModel.handleSelectionViewTapped(.scan)
    }
    
    @IBAction
    func icloudViewTapped(_ sender: Any) {
        viewModel.handleSelectionViewTapped(.icloud)
    }
    
    @IBAction
    func mergeButtonTapped(_ sender: Any) {
        viewModel.handleSelectionViewTapped(.merge)
    }
    
    @IBAction
    func compressButtonTapped(_ sender: Any) {
        viewModel.handleSelectionViewTapped(.compress)
    }
    
    @IBAction
    func photosViewTapped(_ sender: Any) {
        viewModel.handleSelectionViewTapped(.library)
    }
    
    @IBAction
    func docxToPdfViewTapped(_ sender: Any) {
        viewModel.handleSelectionViewTapped(.docxToPdf)
    }
    
    @IBAction
    func excelToPdfViewTapped(_ sender: Any) {
        viewModel.handleSelectionViewTapped(.excelToPdf)
    }
    
    @IBAction
    func pptToPdfViewTapped(_ sender: Any) {
        viewModel.handleSelectionViewTapped(.pptToPdf)
    }
    //MARK: - Private Methods
    
    private func configurePresentation() {
        let presentationController = presentationController as? UISheetPresentationController
        presentationController?.detents = [.custom(resolver: { _ in
            if self.viewModel.isFromHome {
//                return 421
                return 483
            }
            return 311
        })]
    }
}
