//
//  PhotosSelectionViewModel.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 16/01/2024.
//

import Foundation

class PhotosSelectionViewModel: ViewModel {
    
    //MARK: - Enum
    
    enum PhotosSelection {
        case scan
        case icloud
        case library
        case merge
        case compress
        case docxToPdf
        case pptToPdf
        case excelToPdf
    }
    
    //MARK: - Properties
    
    var selectionClosure: ((_ selectedOption: PhotosSelection) -> Void)
    var isFromHome = true
    
    //MARK: - Initializers
    
    init(selectionClosure: @escaping ((_ selectedOption: PhotosSelection) -> Void), isFromHome: Bool) {
        self.selectionClosure = selectionClosure
        self.isFromHome = isFromHome
    }
    
    //MARK: - Methods

    func handleSelectionViewTapped(_ selection: PhotosSelection) {
        router.dismiss()
        selectionClosure(selection)
    }
    
    func handleCancelButtonTapped() {
        router.dismiss()
    }
}
