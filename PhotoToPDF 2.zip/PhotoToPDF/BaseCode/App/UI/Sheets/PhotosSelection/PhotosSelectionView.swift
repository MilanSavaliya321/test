//
//  PhotosSelectionView.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 16/01/2024.
//

import UIKit

class PhotosSelectionView: UIView {
    
    //MARK: - Outlets
    
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var lineView: UIView!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var mergeView: UIView!
    @IBOutlet weak var compressView: UIView!
    
    //MARK: - Override Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        initialSetup()
    }
    
    //MARK: - Private Methods
    
    private func initialSetup() {
        backgroundColor = .clear
        
        contentView.backgroundColor = Asset.whiteBlack.color
        contentView.clipsToBounds = true
        contentView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        contentView.layer.cornerRadius = 16
        
        lineView.layer.cornerRadius = lineView.frame.height / 2
        lineView.backgroundColor = Asset.osloGrayEdward.color
        
        cancelButton.setTitle("Cancel", for: .normal)
        cancelButton.layer.cornerRadius = 12
        cancelButton.layer.borderWidth = 1
        cancelButton.layer.borderColor = Asset.dodgarBlue.color.cgColor
        cancelButton.titleLabel?.font = .current(withWeight: .semibold, andSize: 16)
        cancelButton.setTitleColor(Asset.dodgarBlue.color, for: .normal)
        cancelButton.backgroundColor = Asset.whiteBlack.color
    }
}
