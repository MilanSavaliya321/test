//
//  DeleteView.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 17/12/2023.
//

import UIKit

class DeleteView: UIView {
    
    //MARK: - Outlets
    
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var lineView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var actionButton: UIButton!
    @IBOutlet weak var cancelButton: UIButton!
    
    //MARK: - Override Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        initialSetup()
    }
    
    //MARK: - Private Methods
    
    private func initialSetup() {
        backgroundColor = .clear
        
        contentView.backgroundColor = Asset.whiteBlack.color
        contentView.clipsToBounds = true
        contentView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        contentView.layer.cornerRadius = 16
        
        lineView.layer.cornerRadius = lineView.frame.height / 2
        lineView.backgroundColor = Asset.osloGrayEdward.color
        
        titleLabel.font = .current(withWeight: .bold, andSize: 18)
        titleLabel.textColor = Asset.sharkWhite.color
        
        actionButton.layer.cornerRadius = 12
        actionButton.titleLabel?.font = .current(withWeight: .medium, andSize: 16)
        actionButton.setTitleColor(Asset.scarlet.color, for: .normal)
        actionButton.backgroundColor = Asset.albasterShark.color
        
        cancelButton.setTitle("Cancel", for: .normal)
        cancelButton.titleLabel?.font = .current(withWeight: .semibold, andSize: 16)
        cancelButton.setTitleColor(Asset.nevadaBoulder.color, for: .normal)
    }
}
