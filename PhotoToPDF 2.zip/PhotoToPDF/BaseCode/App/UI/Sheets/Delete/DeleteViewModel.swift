//
//  DeleteViewModel.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 17/12/2023.
//

import Foundation

class DeleteViewModel: ViewModel {
    
    //MARK: - Properties
    
    @Published var title: String
    @Published var actionTitle: String
    var actionButtonClosure: (() -> Void)
    
    //MARK: - Initializers
    
    init(title: String, actionTitle: String, actionButtonClosure: @escaping (() -> Void)) {
        self.title = title
        self.actionTitle = actionTitle
        self.actionButtonClosure = actionButtonClosure
    }
    
    //MARK: - Methods
    
    func handleActionButtonTapped() {
        router.dismiss()
        actionButtonClosure()
    }
    
    func handleCancelButtonTapped() {
        router.dismiss()
    }
}
