//
//  SetPasswordView.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 17/12/2023.
//

import UIKit

class SetPasswordView: UIView {
    
    //MARK: - Outlets
    
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var lineView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var passwordProtectLabel: UILabel!
    @IBOutlet weak var passwordProtectTextFieldView: UIView!
    @IBOutlet weak var passwordProtectTextField: UITextField!
    @IBOutlet weak var passwordProtectVisibilityButton: UIButton!
    
    @IBOutlet weak var reEnterPasswordLabel: UILabel!
    @IBOutlet weak var reEnterPasswordTextFieldView: UIView!
    @IBOutlet weak var reEnterPasswordTextField: UITextField!
    @IBOutlet weak var reEnterPasswordVisibilityButton: UIButton!
    
    @IBOutlet weak var applyButton: UIButton!
    @IBOutlet weak var discardButton: UIButton!
    
    //MARK: - Override Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        initialSetup()
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        
        passwordProtectTextFieldView.layer.borderColor = Asset.ironEdward.color.cgColor
        reEnterPasswordTextFieldView.layer.borderColor = Asset.ironEdward.color.cgColor
    }
    
    
    //MARK: - Private Methods
    
    private func initialSetup() {
        backgroundColor = .clear
        
        contentView.backgroundColor = Asset.whiteBlack.color
        contentView.clipsToBounds = true
        contentView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        contentView.layer.cornerRadius = 16
        
        lineView.layer.cornerRadius = lineView.frame.height / 2
        lineView.backgroundColor = Asset.osloGrayEdward.color
        
        titleLabel.text = "Lock File"
        titleLabel.font = .current(withWeight: .semibold, andSize: 18)
        titleLabel.textColor = Asset.abbeyWhite.color
        
        passwordProtectLabel.text = "Password"
        passwordProtectLabel.font = .current(withWeight: .medium, andSize: 14)
        passwordProtectLabel.textColor = Asset.abbeyWhite.color
        
        passwordProtectTextFieldView.backgroundColor = Asset.albasterShark.color
        passwordProtectTextFieldView.layer.cornerRadius = 10
        passwordProtectTextFieldView.layer.borderWidth = 1
        passwordProtectTextFieldView.layer.borderColor = Asset.ironEdward.color.cgColor
        
        passwordProtectTextField.font = .current(withWeight: .regular, andSize: 14)
        passwordProtectTextField.textColor = Asset.abbeyWhite.color
        
        reEnterPasswordLabel.text = "Re-enter Password"
        reEnterPasswordLabel.font = .current(withWeight: .medium, andSize: 14)
        reEnterPasswordLabel.textColor = Asset.abbeyWhite.color
        
        reEnterPasswordTextFieldView.backgroundColor = Asset.albasterShark.color
        reEnterPasswordTextFieldView.layer.cornerRadius = 10
        reEnterPasswordTextFieldView.layer.borderWidth = 1
        reEnterPasswordTextFieldView.layer.borderColor = Asset.ironEdward.color.cgColor
        
        reEnterPasswordTextField.font = .current(withWeight: .regular, andSize: 14)
        reEnterPasswordTextField.textColor = Asset.abbeyWhite.color
        
        applyButton.layer.cornerRadius = 12
        applyButton.setTitle("Apply", for: .normal)
        applyButton.titleLabel?.font = .current(withWeight: .medium, andSize: 16)
        applyButton.setTitleColor(Asset.dodgarBlue.color, for: .normal)
        applyButton.backgroundColor = Asset.albasterShark.color
        
        discardButton.setTitle("Discard", for: .normal)
        discardButton.titleLabel?.font = .current(withWeight: .semibold, andSize: 16)
        discardButton.setTitleColor(Asset.nevadaBoulder.color, for: .normal)
    }
}
