//
//  FilterViewModel.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 10/12/2023.
//

import Foundation

enum SortOption: Int, CaseIterable {
    
    case latestFirst
    case fileSize
    case name
    case oldestFirst
    
    var title: String {
        switch self {
        case .latestFirst:
            return "By Latest First"
        case .fileSize:
            return "By File Size"
        case .name:
            return "By Name"
        case .oldestFirst:
            return "By Oldest First"
        }
    }
}

class FilterViewModel: ViewModel {
    
    //MARK: - Properties
    
    @Published var selectedOption: SortOption
    var selectedOptionClosure: ((_ option: SortOption) -> Void)
    
    //MARK: - Initializers
    
    init(selectedOption: SortOption, selectedOptionClosure: @escaping (_ option: SortOption) -> Void) {
        self.selectedOption = selectedOption
        self.selectedOptionClosure = selectedOptionClosure
    }
    
    //MARK: - Methods
    
    func handleApplyButtonTapped() {
        router.dismiss()
        selectedOptionClosure(selectedOption)
    }
    
    func handleResetButtonTapped() {
        router.dismiss()
        selectedOptionClosure(.latestFirst)
    }
}
