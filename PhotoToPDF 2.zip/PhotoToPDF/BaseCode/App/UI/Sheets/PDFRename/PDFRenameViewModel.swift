//
//  PDFRenameViewModel.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 16/12/2023.
//

import Foundation

class PDFRenameViewModel: ViewModel {
    
    //MARK: - Properties
    
    @Published var pdfName: String {
        didSet {
            if pdfName.count > maxLimit {
                alert = "Name maximum limit is \(maxLimit)"
                pdfName = String(pdfName.prefix(maxLimit))
            }
        }
    }
    var selectedName: ((_ pdfName: String) -> Void)
    private let maxLimit: Int = 30
    
    //MARK: - Initializers
    
    init(pdfName: String, selectedName: @escaping ((_ pdfName: String) -> Void)) {
        self.pdfName = pdfName
        self.selectedName = selectedName
    }
    
    //MARK: - Methods
    
    func handleApplyButtonTapped() {
        pdfName = pdfName.trimmingCharacters(in: .whitespaces)
        
        guard !pdfName.isEmpty else {
            alert = "Name Cann't be empty"
            return
        }
        guard pdfName.isValidFileName else {
            alert = "InValid FileName"
            return
        }
        router.dismiss()
        selectedName(pdfName)
    }
    
    func handleDiscardButtonTapped() {
        router.dismiss()
    }
}
