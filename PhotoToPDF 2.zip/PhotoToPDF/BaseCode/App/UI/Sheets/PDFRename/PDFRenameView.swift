//
//  PDFRenameView.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 16/12/2023.
//

import UIKit

class PDFRenameView: UIView {
    
    //MARK: - Outlets
    
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var lineView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var fileRenameLabel: UILabel!
    @IBOutlet weak var textFieldContainerView: UIView!
    @IBOutlet weak var pdfNameTextField: UITextField!
    @IBOutlet weak var applyButton: UIButton!
    @IBOutlet weak var discardButton: UIButton!
    
    //MARK: - Override Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        initialSetup()
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        
        textFieldContainerView.layer.borderColor = Asset.ironEdward.color.cgColor
    }
    
    //MARK: - Private Methods
    
    private func initialSetup() {
        backgroundColor = .clear
        
        contentView.backgroundColor = Asset.whiteBlack.color
        contentView.clipsToBounds = true
        contentView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        contentView.layer.cornerRadius = 16
        
        lineView.layer.cornerRadius = lineView.frame.height / 2
        lineView.backgroundColor = Asset.osloGrayEdward.color
        
        titleLabel.text = "Rename File"
        titleLabel.font = .current(withWeight: .semibold, andSize: 18)
        titleLabel.textColor = Asset.abbeyWhite.color
        
        fileRenameLabel.text = "File Name"
        fileRenameLabel.font = .current(withWeight: .medium, andSize: 14)
        fileRenameLabel.textColor = Asset.abbeyWhite.color
        
        textFieldContainerView.backgroundColor = Asset.albasterShark.color
        textFieldContainerView.layer.cornerRadius = 10
        textFieldContainerView.layer.borderWidth = 1
        textFieldContainerView.layer.borderColor = Asset.ironEdward.color.cgColor
        
        pdfNameTextField.font = .current(withWeight: .regular, andSize: 14)
        pdfNameTextField.textColor = Asset.abbeyWhite.color
        
        applyButton.layer.cornerRadius = 12
        applyButton.setTitle("Apply", for: .normal)
        applyButton.titleLabel?.font = .current(withWeight: .medium, andSize: 16)
        applyButton.setTitleColor(Asset.dodgarBlue.color, for: .normal)
        applyButton.backgroundColor = Asset.albasterShark.color
        
        discardButton.setTitle("Discard", for: .normal)
        discardButton.titleLabel?.font = .current(withWeight: .semibold, andSize: 16)
        discardButton.setTitleColor(Asset.nevadaBoulder.color, for: .normal)
    }
}
