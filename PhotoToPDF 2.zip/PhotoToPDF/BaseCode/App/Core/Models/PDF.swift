//
//  PDF.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 16/12/2023.
//

import UIKit

struct PDF: Equatable {
    
    var url: URL
    var data: Data
    var previewImage: UIImage?
    var name: String
    var creationDate: Date
    var isUnlocked: Bool
    var fileNameWithoutExtension: String {
         if name.hasSuffix(".pdf") {
             return String(name.dropLast(4))
         } else {
             return name
         }
     }
}
