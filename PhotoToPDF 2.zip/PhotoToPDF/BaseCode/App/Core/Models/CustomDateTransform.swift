//
//  CustomDateTransform.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 24/01/2024.
//

import Foundation
import ObjectMapper

class CustomDateTransform: TransformType {
    
    typealias Object = Date
    typealias JSON = String
    
    init() {}
    
    func transformFromJSON(_ value: Any?) -> Date? {
        if let dateString = value as? String {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd HH:mm:ss VV"
            return formatter.date(from: dateString)
        }
        return nil
    }
    
    func transformToJSON(_ value: Date?) -> String? {
        if let date = value {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd HH:mm:ss VV"
            return formatter.string(from: date)
        }
        return nil
    }
}
