//
//  PDFOptionsData.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 04/11/2023.
//

import Foundation

struct PDFOptionsData {
    
    var name: String
    var padding: CGFloat
    var boxHeight: CGFloat
}
