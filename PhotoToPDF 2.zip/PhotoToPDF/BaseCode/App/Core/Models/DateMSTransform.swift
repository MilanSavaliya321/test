//
//  DateMSTransform.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 24/01/2024.
//

import Foundation
import ObjectMapper

struct DateMSTransform: TransformType {
    
    typealias Object = Date
    typealias JSON = Int
    
    init() {}
    
    func transformFromJSON(_ value: Any?) -> Date? {
        guard let dateString = value as? String,
              let milliseconds = Double(dateString) else {
            return nil
        }
        return Date(timeIntervalSince1970: milliseconds / 1000.0)
    }
    
    func transformToJSON(_ value: Date?) -> Int? {
        if let date = value {
            return Int(date.timeIntervalSince1970 * 1000)
        }
        return nil
    }
}
