//
//  PurchaseInfo.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 24/01/2024.
//

import Foundation
import ObjectMapper

struct PurchaseInfo: Mappable {
    
    var purchaseDate: Date?
    var expiresDate: Date?
    var purchaseDateMs: Date?
    var expireDateMs: Date?
    var productId: String?
    var quantity: String?

    init?(map: Map) {}

    mutating func mapping(map: Map) {
        purchaseDate <- (map["purchase_date"], CustomDateTransform())
        expiresDate <- (map["expires_date"], CustomDateTransform())
        purchaseDateMs <- (map["purchase_date_ms"], DateMSTransform())
        expireDateMs <- (map["expires_date_ms"], DateMSTransform())
        productId <- map["product_id"]
        quantity <- map["quantity"]
    }
}

extension PurchaseInfo: Codable {
    
    enum CodingKeys: String, CodingKey {
        case purchaseDate = "purchase_date"
        case expiresDate = "expires_date"
        case purchaseDateMs = "purchase_date_ms"
        case expireDateMs = "expires_date_ms"
        case productId = "product_id"
        case quantity
    }
    
    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(purchaseDate, forKey: .purchaseDate)
        try container.encode(expiresDate, forKey: .expiresDate)
        try container.encode(purchaseDateMs, forKey: .purchaseDateMs)
        try container.encode(expireDateMs, forKey: .expireDateMs)
        try container.encode(productId, forKey: .productId)
        try container.encode(quantity, forKey: .quantity)
    }
}
