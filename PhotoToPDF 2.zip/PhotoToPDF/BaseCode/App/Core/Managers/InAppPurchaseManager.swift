//
//  IAPManager.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 13/01/2024.
//

import ObjectMapper
import StoreKit

class InAppPurchaseManager: NSObject, SKPaymentTransactionObserver {
    
    //MARK: - Enum
    
    enum PurchaseStatus {
        case inProcess
        case completed
        case failed(error: Error?)
    }
    
    //MARK: - Properties
    
    static let shared = InAppPurchaseManager()
    var productsRequest: SKProductsRequest?
    @Published var products: [SKProduct] = []
    private var purchaseCompletion: ((PurchaseStatus) -> Void)?
    
    //MARK: - Initializers
    
    override init() {
        super.init()
        SKPaymentQueue.default().add(self)
    }
    
    //MARK: - Methods
    
    func fetchProducts() {
        let productIdentifiers: Set<String> = ["com.pdf.monthly","com.pdf.yearly","pdf_1999_l"]
        
        productsRequest = SKProductsRequest(productIdentifiers: productIdentifiers)
        productsRequest?.delegate = self
        
        productsRequest?.start()
    }
    
    func purchaseProduct(_ product: SKProduct, completion: @escaping (PurchaseStatus) -> Void) {
        guard SKPaymentQueue.canMakePayments() else {
            completion(.failed(error: nil))
            return
        }
        
        let payment = SKPayment(product: product)
        SKPaymentQueue.default().add(payment)
        
        purchaseCompletion = completion
    }
    
    func paymentQueue(_ queue: SKPaymentQueue, updatedTransactions transactions: [SKPaymentTransaction]) {
        for transaction in transactions {
            switch transaction.transactionState {
            case .purchasing:
                purchaseCompletion?(.inProcess)
                
            case .purchased:
                fetchActiveReceipts { receipts in
                    StorageService.activeReceipts = receipts ?? []
                    StorageService.isSubscribed = !(receipts?.isEmpty ?? true)
                    guard let receipts,
                          !receipts.isEmpty else {
                        SKPaymentQueue.default().finishTransaction(transaction)
                        self.purchaseCompletion?(.failed(error: nil))
                        return
                    }
                    SKPaymentQueue.default().finishTransaction(transaction)
                    self.purchaseCompletion?(.completed)
                }
                
            case .failed:
                SKPaymentQueue.default().finishTransaction(transaction)
                purchaseCompletion?(.failed(error: transaction.error))
                
            case .restored:
                fetchActiveReceipts { receipts in
                    StorageService.activeReceipts = receipts ?? []
                    StorageService.isSubscribed = !(receipts?.isEmpty ?? true)
                    guard let receipts,
                          !receipts.isEmpty else {
                        SKPaymentQueue.default().finishTransaction(transaction)
                        self.purchaseCompletion?(.failed(error: nil))
                        return
                    }
                    SKPaymentQueue.default().finishTransaction(transaction)
                    self.purchaseCompletion?(.completed)
                }
                
            case .deferred:
                purchaseCompletion?(.inProcess)
                
            default:
                break
            }
        }
    }
    
    func fetchActiveReceipts(completion: @escaping ([PurchaseInfo]?) -> Void) {
        if let appStoreReceiptURL = Bundle.main.appStoreReceiptURL,
           FileManager.default.fileExists(atPath: appStoreReceiptURL.path) {
            do {
                let receiptData = try Data(contentsOf: appStoreReceiptURL)
                fetchReceipts(receiptData: receiptData) {
                    let pProducts = $0?.filter { receiptData in
                        guard let expireDate = receiptData.expireDateMs else {
                            return true
                        }
                        return expireDate > Date()
                    }
                    
                    if let lastPurchase = pProducts?.last {
                        completion([lastPurchase])
                    } else {
                              completion(nil)
                    }
//                    completion($0?.filter { receiptData in
//                        guard let expireDate = receiptData.expireDateMs else {
//                            return true
//                        }
//                        return expireDate > Date()
//                    })
                }
            } catch {
                completion(nil)
            }
        } else {
            completion(nil)
        }
    }
    
   
    private func fetchReceipts(receiptData: Data, completion: @escaping ([PurchaseInfo]?) -> Void) {
        let receiptString = receiptData.base64EncodedString(options: [])
        let requestData = ["receipt-data": receiptString,
                           "password": "507746a041814c2b90b7883b425d7ee7"]
        
        do {
            let requestData = try JSONSerialization.data(withJSONObject: requestData, options: [])
//            "https://sandbox.itunes.apple.com/verifyReceipt"
//            "https://buy.itunes.apple.com/verifyReceipt"
//            guard let validationURL = URL(string: "https://sandbox.itunes.apple.com/verifyReceipt") else {
//                completion(nil)
//                return
//            }
            
            guard let validationURL = URL(string: "https://buy.itunes.apple.com/verifyReceipt") else {
                completion(nil)
                return
            }
            
            
            var request = URLRequest(url: validationURL)
            request.httpMethod = "POST"
            request.httpBody = requestData
            
            let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                if let data = data,
                   let jsonResponse = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                   let latestPurchases = jsonResponse["latest_receipt_info"] as? [[String: Any]] {
                    let purchases = Mapper<PurchaseInfo>().mapArray(JSONArray: latestPurchases)
                    completion(purchases)
                } else {
                    completion(nil)
                }
            }
            task.resume()
        } catch {
            completion(nil)
        }
    }
    
    deinit {
        SKPaymentQueue.default().remove(self)
    }
}

//MARK: - SKProductsRequestDelegate Methods

extension InAppPurchaseManager: SKProductsRequestDelegate {
    
    func productsRequest(_ request: SKProductsRequest, didReceive response: SKProductsResponse) {
        products = response.products
    }
}
