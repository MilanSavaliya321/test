//
//  SubscriptionManager.swift
//  BaseCode
//
//  Created by BrainX IOS Dev on 31/12/2023.
//

import Foundation
//import RevenueCat

class SubscriptionManager: ObservableObject {
    
//    //MARK: - Properties
//    
//    private let premiumEntitlement = "Pro"
//    private(set) var isPremium = false
//    
//    //MARK: - Initializers
//    
//    init() {
//        Purchases.logLevel = .debug
//        Purchases.configure(withAPIKey: "appl_GeqOZWTSRFDbVkSZwgNebUtVHpi")
//    }
//
//    //MARK: - Methods
//    
//    func getOfferings(_ completion: @escaping ([Package]) -> Void) {
//        Purchases.shared.getOfferings { (offerings, error) in
//            let packages = offerings?.current?.availablePackages ?? []
//            completion(packages)
//        }
//    }
//    
//    func getPremiumStatus(_ completion: @escaping (Bool) -> Void) {
//        Purchases.shared.getCustomerInfo { (customerInfo, error) in
//            guard let customerInfo = customerInfo,
//                  error == nil else {
//                completion(false)
//                return
//            }
//            
//            let isPremium = customerInfo.entitlements.all[self.premiumEntitlement]?.isActive == true
//            self.isPremium = isPremium
//            completion(isPremium)
//        }
//    }
//    
//    func restorePurchase(_ completion: @escaping () -> Void) {
//        Purchases.shared.restorePurchases { (info, error) in
//            let isPremium = info?.entitlements[self.premiumEntitlement]?.isActive == true
//            self.isPremium = isPremium
//            completion()
//        }
//    }
//    
//    func purchasePackage(_ package: Package, with completion: @escaping (Bool) -> Void) {
//        Purchases.shared.purchase(package: package) { (_, customerInfo, _, _) in
//            guard let customerInfo = customerInfo else {
//                completion(false)
//                return
//            }
//            
//            let isPremium = customerInfo.entitlements.all[self.premiumEntitlement]?.isActive == true
//            self.isPremium = isPremium
//            completion(isPremium)
//        }
//    }
}
