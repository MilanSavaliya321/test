//
//  UserDefault.swift
//  BaseCode
//
//  Created by  on 27/07/2023.
//

import Foundation

@propertyWrapper
struct Storage<T: Codable> {

    private let key: String
    private let defaultValue: T
    private let container: UserDefaults = .standard

    init(wrappedValue: T, _ key: String) {
        self.key = key
        self.defaultValue = wrappedValue
    }

    public var wrappedValue: T {
        get {
            guard let data = container.data(forKey: key),
                  let decodedValue = try?
                    JSONDecoder().decode(T.self, from: data) else {
                return defaultValue
            }
            return decodedValue
        }
        set {
            if let optional = newValue as? Nilable,
               optional.isNil {
                container.removeObject(forKey: key)
                return
            }
            
            guard let data = try? JSONEncoder().encode(newValue) else {
                return
            }
            container.set(data, forKey: key)

        }
    }
}

extension Storage where T: ExpressibleByNilLiteral {
    
    init(_ key: String) {
        self.init(wrappedValue: nil, key)
    }
}

class StorageService {
    
    @Storage("favoritePDFs") static var favoritePDFs: [URL] = []
    @Storage("isSubscribed") static var isSubscribed: Bool = false
    @Storage("activeReceipts") static var activeReceipts: [PurchaseInfo] = []
    @Storage("savedPDFs") static var savedPDFs: Int = 0
    @Storage("lockedPDFs") static var lockedPDFs: Int = 0
}
