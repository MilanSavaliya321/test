//
//  OptionalValue.swift
//  BaseCode
//
//  Created by BrainX iOS on 20/10/2023.
//

import Foundation

public protocol Nilable {
    var isNil: Bool { get }
}

extension Optional: Nilable {
    public var isNil: Bool {
        self == nil
    }
}
