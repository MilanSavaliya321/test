// swiftlint:disable all
// Generated using SwiftGen — https://github.com/SwiftGen/SwiftGen

#if os(macOS)
  import AppKit
#elseif os(iOS)
  import UIKit
#elseif os(tvOS) || os(watchOS)
  import UIKit
#endif
#if canImport(SwiftUI)
  import SwiftUI
#endif

// Deprecated typealiases
@available(*, deprecated, renamed: "ColorAsset.Color", message: "This typealias will be removed in SwiftGen 7.0")
internal typealias AssetColorTypeAlias = ColorAsset.Color
@available(*, deprecated, renamed: "ImageAsset.Image", message: "This typealias will be removed in SwiftGen 7.0")
internal typealias AssetImageTypeAlias = ImageAsset.Image

// swiftlint:disable superfluous_disable_command file_length implicit_return

// MARK: - Asset Catalogs

// swiftlint:disable identifier_name line_length nesting type_body_length type_name
internal enum Asset {
  internal static let abbeyWhite = ColorAsset(name: "abbey_white")
  internal static let albasterShark = ColorAsset(name: "albaster_shark")
  internal static let background = ColorAsset(name: "background")
  internal static let blackWhite = ColorAsset(name: "blackWhite")
  internal static let capeCodWhite = ColorAsset(name: "capeCod_white")
  internal static let denim = ColorAsset(name: "denim")
  internal static let dodgarBlue = ColorAsset(name: "dodgarBlue")
  internal static let frenchPass = ColorAsset(name: "frenchPass")
  internal static let galleryBoulder = ColorAsset(name: "gallery_boulder")
  internal static let grayBoulder = ColorAsset(name: "grayBoulder")
  internal static let ironEdward = ColorAsset(name: "ironEdward")
  internal static let mercuryShark = ColorAsset(name: "mercuryShark")
  internal static let nevadaBoulder = ColorAsset(name: "nevada_boulder")
  internal static let osloGrayEdward = ColorAsset(name: "osloGray_edward")
  internal static let scarlet = ColorAsset(name: "scarlet")
  internal static let selectiveYellow = ColorAsset(name: "selectiveYellow")
  internal static let sharkWhite = ColorAsset(name: "sharkWhite")
  internal static let tunaWhite = ColorAsset(name: "tunaWhite")
  internal static let whiteBlack = ColorAsset(name: "whiteBlack")
  internal static let whiteShark = ColorAsset(name: "whiteShark")
  internal static let greyBorder = ColorAsset(name: "greyBorder")
  internal static let wildSandShark = ColorAsset(name: "wildSandShark")
  internal static let woodSmoke = ColorAsset(name: "woodSmoke")
  internal static let add = ImageAsset(name: "add")
  internal static let add2 = ImageAsset(name: "add2")
  internal static let backArrow = ImageAsset(name: "backArrow")
  internal static let blueDiamond = ImageAsset(name: "blueDiamond")
  internal static let blueTick = ImageAsset(name: "blueTick")
  internal static let camera = ImageAsset(name: "camera")
  internal static let checkedCircle = ImageAsset(name: "checkedCircle")
  internal static let cross = ImageAsset(name: "cross")
  internal static let dashedBorder = ImageAsset(name: "dashedBorder")
  internal static let favouriteSelected = ImageAsset(name: "favouriteSelected")
  internal static let favouriteUnSelected = ImageAsset(name: "favouriteUnSelected")
  internal static let folderIcon = ImageAsset(name: "folderIcon")
  internal static let gallery = ImageAsset(name: "gallery")
  internal static let gallery2 = ImageAsset(name: "gallery2")
  internal static let getHelpIcon = ImageAsset(name: "getHelpIcon")
  internal static let home = ImageAsset(name: "home")
  internal static let horizontalLines = ImageAsset(name: "horizontalLines")
  internal static let icloud = ImageAsset(name: "icloud")
  internal static let isPurchased = ImageAsset(name: "isPurchased")
  internal static let loaderImage = ImageAsset(name: "loaderImage")
  internal static let lock = ImageAsset(name: "lock")
  internal static let lockEye = ImageAsset(name: "lockEye")
  internal static let nextArrow = ImageAsset(name: "nextArrow")
  internal static let pdfPreviewImage = ImageAsset(name: "pdfPreviewImage")
  internal static let privacyPolicyIcon = ImageAsset(name: "privacyPolicyIcon")
  internal static let rateIcon = ImageAsset(name: "rateIcon")
  internal static let redDiamond = ImageAsset(name: "redDiamond")
  internal static let redTick = ImageAsset(name: "redTick")
  internal static let renameicon = ImageAsset(name: "renameicon")
  internal static let saveIcon = ImageAsset(name: "saveIcon")
  internal static let scan = ImageAsset(name: "scan")
  internal static let search = ImageAsset(name: "search")
  internal static let settings = ImageAsset(name: "settings")
  internal static let shareAppIcon = ImageAsset(name: "shareAppIcon")
  internal static let shareIcon = ImageAsset(name: "shareIcon")
  internal static let splashIcon = ImageAsset(name: "splashIcon")
  internal static let termsOfServiceIcon = ImageAsset(name: "termsOfServiceIcon")
  internal static let threeDots = ImageAsset(name: "threeDots")
  internal static let threeLines = ImageAsset(name: "threeLines")
  internal static let unLockEye = ImageAsset(name: "unLockEye")
  internal static let uncheckedCircle = ImageAsset(name: "uncheckedCircle")
  internal static let whiteDiamond = ImageAsset(name: "whiteDiamond")
  internal static let lightPinkBorder = ColorAsset(name: "lightPinkBorder")
  internal static let lightBlue = ColorAsset(name: "lightBlue")
  internal static let qrCodeScanner = ImageAsset(name: "qrCodeScanner")

}
// swiftlint:enable identifier_name line_length nesting type_body_length type_name

// MARK: - Implementation Details

internal final class ColorAsset {
  internal fileprivate(set) var name: String

  #if os(macOS)
  internal typealias Color = NSColor
  #elseif os(iOS) || os(tvOS) || os(watchOS)
  internal typealias Color = UIColor
  #endif

  @available(iOS 11.0, tvOS 11.0, watchOS 4.0, macOS 10.13, *)
  internal private(set) lazy var color: Color = {
    guard let color = Color(asset: self) else {
      fatalError("Unable to load color asset named \(name).")
    }
    return color
  }()

  #if os(iOS) || os(tvOS)
  @available(iOS 11.0, tvOS 11.0, *)
  internal func color(compatibleWith traitCollection: UITraitCollection) -> Color {
    let bundle = BundleToken.bundle
    guard let color = Color(named: name, in: bundle, compatibleWith: traitCollection) else {
      fatalError("Unable to load color asset named \(name).")
    }
    return color
  }
  #endif

  #if canImport(SwiftUI)
  @available(iOS 13.0, tvOS 13.0, watchOS 6.0, macOS 10.15, *)
  internal private(set) lazy var swiftUIColor: SwiftUI.Color = {
    SwiftUI.Color(asset: self)
  }()
  #endif

  fileprivate init(name: String) {
    self.name = name
  }
}

internal extension ColorAsset.Color {
  @available(iOS 11.0, tvOS 11.0, watchOS 4.0, macOS 10.13, *)
  convenience init?(asset: ColorAsset) {
    let bundle = BundleToken.bundle
    #if os(iOS) || os(tvOS)
    self.init(named: asset.name, in: bundle, compatibleWith: nil)
    #elseif os(macOS)
    self.init(named: NSColor.Name(asset.name), bundle: bundle)
    #elseif os(watchOS)
    self.init(named: asset.name)
    #endif
  }
}

#if canImport(SwiftUI)
@available(iOS 13.0, tvOS 13.0, watchOS 6.0, macOS 10.15, *)
internal extension SwiftUI.Color {
  init(asset: ColorAsset) {
    let bundle = BundleToken.bundle
    self.init(asset.name, bundle: bundle)
  }
}
#endif

internal struct ImageAsset {
  internal fileprivate(set) var name: String

  #if os(macOS)
  internal typealias Image = NSImage
  #elseif os(iOS) || os(tvOS) || os(watchOS)
  internal typealias Image = UIImage
  #endif

  @available(iOS 8.0, tvOS 9.0, watchOS 2.0, macOS 10.7, *)
  internal var image: Image {
    let bundle = BundleToken.bundle
    #if os(iOS) || os(tvOS)
    let image = Image(named: name, in: bundle, compatibleWith: nil)
    #elseif os(macOS)
    let name = NSImage.Name(self.name)
    let image = (bundle == .main) ? NSImage(named: name) : bundle.image(forResource: name)
    #elseif os(watchOS)
    let image = Image(named: name)
    #endif
    guard let result = image else {
      fatalError("Unable to load image asset named \(name).")
    }
    return result
  }

  #if os(iOS) || os(tvOS)
  @available(iOS 8.0, tvOS 9.0, *)
  internal func image(compatibleWith traitCollection: UITraitCollection) -> Image {
    let bundle = BundleToken.bundle
    guard let result = Image(named: name, in: bundle, compatibleWith: traitCollection) else {
      fatalError("Unable to load image asset named \(name).")
    }
    return result
  }
  #endif

  #if canImport(SwiftUI)
  @available(iOS 13.0, tvOS 13.0, watchOS 6.0, macOS 10.15, *)
  internal var swiftUIImage: SwiftUI.Image {
    SwiftUI.Image(asset: self)
  }
  #endif
}

internal extension ImageAsset.Image {
  @available(iOS 8.0, tvOS 9.0, watchOS 2.0, *)
  @available(macOS, deprecated,
    message: "This initializer is unsafe on macOS, please use the ImageAsset.image property")
  convenience init?(asset: ImageAsset) {
    #if os(iOS) || os(tvOS)
    let bundle = BundleToken.bundle
    self.init(named: asset.name, in: bundle, compatibleWith: nil)
    #elseif os(macOS)
    self.init(named: NSImage.Name(asset.name))
    #elseif os(watchOS)
    self.init(named: asset.name)
    #endif
  }
}

#if canImport(SwiftUI)
@available(iOS 13.0, tvOS 13.0, watchOS 6.0, macOS 10.15, *)
internal extension SwiftUI.Image {
  init(asset: ImageAsset) {
    let bundle = BundleToken.bundle
    self.init(asset.name, bundle: bundle)
  }

  init(asset: ImageAsset, label: Text) {
    let bundle = BundleToken.bundle
    self.init(asset.name, bundle: bundle, label: label)
  }

  init(decorative asset: ImageAsset) {
    let bundle = BundleToken.bundle
    self.init(decorative: asset.name, bundle: bundle)
  }
}
#endif

// swiftlint:disable convenience_type
private final class BundleToken {
  static let bundle: Bundle = {
    #if SWIFT_PACKAGE
    return Bundle.module
    #else
    return Bundle(for: BundleToken.self)
    #endif
  }()
}
// swiftlint:enable convenience_type
